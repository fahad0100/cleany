// Fetches raw JSON and propagates exceptions to the repository.
import 'package:cleany_store/core/network/retrofit/contract_sample_api.dart';

/// Fetches raw JSON and propagates exceptions to the repository.
class ContractSampleRemoteDataSource {
  const ContractSampleRemoteDataSource(this._api);
  final ContractSampleApi _api;
  // Raw JSON only. Conversion and Failure mapping belong to the repository.
  Future<Map<String, dynamic>> fetch() => _api.fetch();
}
