// Converts JSON/models into entities and returns Success or Failure exactly once.
import 'package:multiple_result/multiple_result.dart';
import 'package:cleany_store/core/errors/failure.dart';
import 'package:cleany_store/core/errors/error_reporter.dart';
import 'package:cleany_store/core/network/failure_mapper.dart';
import 'package:cleany_store/features/contract_sample/domain/entities/contract_sample_entity.dart';
import 'package:cleany_store/features/contract_sample/domain/repositories/contract_sample_repository.dart';

import '../datasources/contract_sample_remote_data_source.dart';
import '../models/contract_sample_model.dart';

/// Converts JSON/models into entities and returns Success or Failure exactly once.
class ContractSampleRepositoryImpl implements ContractSampleRepository {
  const ContractSampleRepositoryImpl(
    this._remote, {
    this.reportError = reportUnexpectedError,
  });
  final ContractSampleRemoteDataSource _remote;
  final ErrorReporter reportError;
  @override
  Future<Result<ContractSampleEntity, Failure>> fetch() async {
    try {
      final json = await _remote.fetch();
      final model = ContractSampleModel.fromJson(json);
      return Success(
        ContractSampleEntity(
          id: model.id,
          count: model.count,
          price: model.price,
          enabled: model.enabled,
          createdAt: model.createdAt,
          values: model.values,
          tags: model.tags,
          integers: model.integers,
          numbers: model.numbers,
          rows: model.rows,
          metadata: model.metadata,
          selection: model.selection,
          payload: model.payload,
        ),
      );
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) reportError(error, stackTrace);
      return Error(failure);
    }
  }
}
