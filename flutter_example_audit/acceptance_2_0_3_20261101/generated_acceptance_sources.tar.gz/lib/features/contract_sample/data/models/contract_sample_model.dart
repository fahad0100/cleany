// Defines the API data model and its generated JSON serialization.
// Freezed forwards JSON annotations to the generated properties.
// ignore_for_file: invalid_annotation_target
import 'package:freezed_annotation/freezed_annotation.dart';
part 'contract_sample_model.freezed.dart';
part 'contract_sample_model.g.dart';

/// Defines the API data model and its generated JSON serialization.
@freezed
abstract class ContractSampleModel with _$ContractSampleModel {
  const factory ContractSampleModel({
    required String id,
    required int count,
    required double price,
    required bool enabled,
    required DateTime createdAt,
    required List<dynamic> values,
    required List<String> tags,
    required List<int> integers,
    required List<num> numbers,
    required List<Map<String, dynamic>> rows,
    Map<String, dynamic>? metadata,
    required Set<dynamic> selection,
    dynamic payload,
  }) = _ContractSampleModel;
  factory ContractSampleModel.fromJson(Map<String, dynamic> json) =>
      _$ContractSampleModelFromJson(json);
}
