// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contract_sample_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_ContractSampleModel _$ContractSampleModelFromJson(Map<String, dynamic> json) =>
    _ContractSampleModel(
      id: json['id'] as String,
      count: (json['count'] as num).toInt(),
      price: (json['price'] as num).toDouble(),
      enabled: json['enabled'] as bool,
      createdAt: DateTime.parse(json['createdAt'] as String),
      values: json['values'] as List<dynamic>,
      tags: (json['tags'] as List<dynamic>).map((e) => e as String).toList(),
      integers: (json['integers'] as List<dynamic>)
          .map((e) => (e as num).toInt())
          .toList(),
      numbers: (json['numbers'] as List<dynamic>).map((e) => e as num).toList(),
      rows: (json['rows'] as List<dynamic>)
          .map((e) => e as Map<String, dynamic>)
          .toList(),
      metadata: json['metadata'] as Map<String, dynamic>?,
      selection: (json['selection'] as List<dynamic>).toSet(),
      payload: json['payload'],
    );

Map<String, dynamic> _$ContractSampleModelToJson(
  _ContractSampleModel instance,
) => <String, dynamic>{
  'id': instance.id,
  'count': instance.count,
  'price': instance.price,
  'enabled': instance.enabled,
  'createdAt': instance.createdAt.toIso8601String(),
  'values': instance.values,
  'tags': instance.tags,
  'integers': instance.integers,
  'numbers': instance.numbers,
  'rows': instance.rows,
  'metadata': instance.metadata,
  'selection': instance.selection.toList(),
  'payload': instance.payload,
};
