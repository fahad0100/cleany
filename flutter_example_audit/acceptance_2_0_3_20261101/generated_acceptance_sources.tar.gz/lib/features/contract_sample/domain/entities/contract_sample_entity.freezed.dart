// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'contract_sample_entity.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$ContractSampleEntity {

 String get id; int get count; double get price; bool get enabled; DateTime get createdAt; List<dynamic> get values; List<String> get tags; List<int> get integers; List<num> get numbers; List<Map<String, dynamic>> get rows; Map<String, dynamic>? get metadata; Set<dynamic> get selection; dynamic get payload;
/// Create a copy of ContractSampleEntity
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ContractSampleEntityCopyWith<ContractSampleEntity> get copyWith => _$ContractSampleEntityCopyWithImpl<ContractSampleEntity>(this as ContractSampleEntity, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as ContractSampleEntity;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ContractSampleEntity&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.count, _this.count) || other.count == _this.count)&&(identical(other.price, _this.price) || other.price == _this.price)&&(identical(other.enabled, _this.enabled) || other.enabled == _this.enabled)&&(identical(other.createdAt, _this.createdAt) || other.createdAt == _this.createdAt)&&const DeepCollectionEquality().equals(other.values, _this.values)&&const DeepCollectionEquality().equals(other.tags, _this.tags)&&const DeepCollectionEquality().equals(other.integers, _this.integers)&&const DeepCollectionEquality().equals(other.numbers, _this.numbers)&&const DeepCollectionEquality().equals(other.rows, _this.rows)&&const DeepCollectionEquality().equals(other.metadata, _this.metadata)&&const DeepCollectionEquality().equals(other.selection, _this.selection)&&const DeepCollectionEquality().equals(other.payload, _this.payload));
}


@override
int get hashCode {
  final _this = this as ContractSampleEntity;
  return Object.hash(runtimeType,_this.id,_this.count,_this.price,_this.enabled,_this.createdAt,const DeepCollectionEquality().hash(_this.values),const DeepCollectionEquality().hash(_this.tags),const DeepCollectionEquality().hash(_this.integers),const DeepCollectionEquality().hash(_this.numbers),const DeepCollectionEquality().hash(_this.rows),const DeepCollectionEquality().hash(_this.metadata),const DeepCollectionEquality().hash(_this.selection),const DeepCollectionEquality().hash(_this.payload));
}

@override
String toString() {
  final _this = this as ContractSampleEntity;
  return 'ContractSampleEntity(id: ${_this.id}, count: ${_this.count}, price: ${_this.price}, enabled: ${_this.enabled}, createdAt: ${_this.createdAt}, values: ${_this.values}, tags: ${_this.tags}, integers: ${_this.integers}, numbers: ${_this.numbers}, rows: ${_this.rows}, metadata: ${_this.metadata}, selection: ${_this.selection}, payload: ${_this.payload})';
}


}

/// @nodoc
abstract mixin class $ContractSampleEntityCopyWith<$Res>  {
  factory $ContractSampleEntityCopyWith(ContractSampleEntity value, $Res Function(ContractSampleEntity) _then) = _$ContractSampleEntityCopyWithImpl;
@useResult
$Res call({
 String id, int count, double price, bool enabled, DateTime createdAt, List<dynamic> values, List<String> tags, List<int> integers, List<num> numbers, List<Map<String, dynamic>> rows, Map<String, dynamic>? metadata, Set<dynamic> selection, dynamic payload
});




}
/// @nodoc
class _$ContractSampleEntityCopyWithImpl<$Res>
    implements $ContractSampleEntityCopyWith<$Res> {
  _$ContractSampleEntityCopyWithImpl(this._self, this._then);

  final ContractSampleEntity _self;
  final $Res Function(ContractSampleEntity) _then;

/// Create a copy of ContractSampleEntity
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? count = null,Object? price = null,Object? enabled = null,Object? createdAt = null,Object? values = null,Object? tags = null,Object? integers = null,Object? numbers = null,Object? rows = null,Object? metadata = freezed,Object? selection = null,Object? payload = freezed,}) {
  return _then(ContractSampleEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,count: null == count ? _self.count : count // ignore: cast_nullable_to_non_nullable
as int,price: null == price ? _self.price : price // ignore: cast_nullable_to_non_nullable
as double,enabled: null == enabled ? _self.enabled : enabled // ignore: cast_nullable_to_non_nullable
as bool,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,values: null == values ? _self.values : values // ignore: cast_nullable_to_non_nullable
as List<dynamic>,tags: null == tags ? _self.tags : tags // ignore: cast_nullable_to_non_nullable
as List<String>,integers: null == integers ? _self.integers : integers // ignore: cast_nullable_to_non_nullable
as List<int>,numbers: null == numbers ? _self.numbers : numbers // ignore: cast_nullable_to_non_nullable
as List<num>,rows: null == rows ? _self.rows : rows // ignore: cast_nullable_to_non_nullable
as List<Map<String, dynamic>>,metadata: freezed == metadata ? _self.metadata : metadata // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>?,selection: null == selection ? _self.selection : selection // ignore: cast_nullable_to_non_nullable
as Set<dynamic>,payload: freezed == payload ? _self.payload : payload // ignore: cast_nullable_to_non_nullable
as dynamic,
  ));
}

}


/// Adds pattern-matching-related methods to [ContractSampleEntity].
extension ContractSampleEntityPatterns on ContractSampleEntity {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _ContractSampleEntity value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _ContractSampleEntity() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _ContractSampleEntity value)  $default,){
final _that = this;
switch (_that) {
case _ContractSampleEntity():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _ContractSampleEntity value)?  $default,){
final _that = this;
switch (_that) {
case _ContractSampleEntity() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  int count,  double price,  bool enabled,  DateTime createdAt,  List<dynamic> values,  List<String> tags,  List<int> integers,  List<num> numbers,  List<Map<String, dynamic>> rows,  Map<String, dynamic>? metadata,  Set<dynamic> selection,  dynamic payload)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _ContractSampleEntity() when $default != null:
return $default(_that.id,_that.count,_that.price,_that.enabled,_that.createdAt,_that.values,_that.tags,_that.integers,_that.numbers,_that.rows,_that.metadata,_that.selection,_that.payload);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  int count,  double price,  bool enabled,  DateTime createdAt,  List<dynamic> values,  List<String> tags,  List<int> integers,  List<num> numbers,  List<Map<String, dynamic>> rows,  Map<String, dynamic>? metadata,  Set<dynamic> selection,  dynamic payload)  $default,) {final _that = this;
switch (_that) {
case _ContractSampleEntity():
return $default(_that.id,_that.count,_that.price,_that.enabled,_that.createdAt,_that.values,_that.tags,_that.integers,_that.numbers,_that.rows,_that.metadata,_that.selection,_that.payload);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  int count,  double price,  bool enabled,  DateTime createdAt,  List<dynamic> values,  List<String> tags,  List<int> integers,  List<num> numbers,  List<Map<String, dynamic>> rows,  Map<String, dynamic>? metadata,  Set<dynamic> selection,  dynamic payload)?  $default,) {final _that = this;
switch (_that) {
case _ContractSampleEntity() when $default != null:
return $default(_that.id,_that.count,_that.price,_that.enabled,_that.createdAt,_that.values,_that.tags,_that.integers,_that.numbers,_that.rows,_that.metadata,_that.selection,_that.payload);case _:
  return null;

}
}

}

/// @nodoc


class _ContractSampleEntity implements ContractSampleEntity {
  const _ContractSampleEntity({required this.id, required this.count, required this.price, required this.enabled, required this.createdAt, required  List<dynamic> values, required  List<String> tags, required  List<int> integers, required  List<num> numbers, required  List<Map<String, dynamic>> rows,  Map<String, dynamic>? metadata, required  Set<dynamic> selection, this.payload}): _values = values,_tags = tags,_integers = integers,_numbers = numbers,_rows = rows,_metadata = metadata,_selection = selection;
  

@override final  String id;
@override final  int count;
@override final  double price;
@override final  bool enabled;
@override final  DateTime createdAt;
 final  List<dynamic> _values;
@override List<dynamic> get values {
  if (_values is EqualUnmodifiableListView) return _values;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_values);
}

 final  List<String> _tags;
@override List<String> get tags {
  if (_tags is EqualUnmodifiableListView) return _tags;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_tags);
}

 final  List<int> _integers;
@override List<int> get integers {
  if (_integers is EqualUnmodifiableListView) return _integers;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_integers);
}

 final  List<num> _numbers;
@override List<num> get numbers {
  if (_numbers is EqualUnmodifiableListView) return _numbers;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_numbers);
}

 final  List<Map<String, dynamic>> _rows;
@override List<Map<String, dynamic>> get rows {
  if (_rows is EqualUnmodifiableListView) return _rows;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_rows);
}

 final  Map<String, dynamic>? _metadata;
@override Map<String, dynamic>? get metadata {
  final value = _metadata;
  if (value == null) return null;
  if (_metadata is EqualUnmodifiableMapView) return _metadata;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableMapView(value);
}

 final  Set<dynamic> _selection;
@override Set<dynamic> get selection {
  if (_selection is EqualUnmodifiableSetView) return _selection;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableSetView(_selection);
}

@override final  dynamic payload;

/// Create a copy of ContractSampleEntity
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$ContractSampleEntityCopyWith<_ContractSampleEntity> get copyWith => __$ContractSampleEntityCopyWithImpl<_ContractSampleEntity>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _ContractSampleEntity&&(identical(other.id, id) || other.id == id)&&(identical(other.count, count) || other.count == count)&&(identical(other.price, price) || other.price == price)&&(identical(other.enabled, enabled) || other.enabled == enabled)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&const DeepCollectionEquality().equals(other.values, _values)&&const DeepCollectionEquality().equals(other.tags, _tags)&&const DeepCollectionEquality().equals(other.integers, _integers)&&const DeepCollectionEquality().equals(other.numbers, _numbers)&&const DeepCollectionEquality().equals(other.rows, _rows)&&const DeepCollectionEquality().equals(other.metadata, _metadata)&&const DeepCollectionEquality().equals(other.selection, _selection)&&const DeepCollectionEquality().equals(other.payload, payload));
}


@override
int get hashCode {
    return Object.hash(runtimeType,id,count,price,enabled,createdAt,const DeepCollectionEquality().hash(_values),const DeepCollectionEquality().hash(_tags),const DeepCollectionEquality().hash(_integers),const DeepCollectionEquality().hash(_numbers),const DeepCollectionEquality().hash(_rows),const DeepCollectionEquality().hash(_metadata),const DeepCollectionEquality().hash(_selection),const DeepCollectionEquality().hash(payload));
}

@override
String toString() {
    return 'ContractSampleEntity(id: $id, count: $count, price: $price, enabled: $enabled, createdAt: $createdAt, values: $values, tags: $tags, integers: $integers, numbers: $numbers, rows: $rows, metadata: $metadata, selection: $selection, payload: $payload)';
}


}

/// @nodoc
abstract mixin class _$ContractSampleEntityCopyWith<$Res> implements $ContractSampleEntityCopyWith<$Res> {
  factory _$ContractSampleEntityCopyWith(_ContractSampleEntity value, $Res Function(_ContractSampleEntity) _then) = __$ContractSampleEntityCopyWithImpl;
@override @useResult
$Res call({
 String id, int count, double price, bool enabled, DateTime createdAt, List<dynamic> values, List<String> tags, List<int> integers, List<num> numbers, List<Map<String, dynamic>> rows, Map<String, dynamic>? metadata, Set<dynamic> selection, dynamic payload
});




}
/// @nodoc
class __$ContractSampleEntityCopyWithImpl<$Res>
    implements _$ContractSampleEntityCopyWith<$Res> {
  __$ContractSampleEntityCopyWithImpl(this._self, this._then);

  final _ContractSampleEntity _self;
  final $Res Function(_ContractSampleEntity) _then;

/// Create a copy of ContractSampleEntity
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? count = null,Object? price = null,Object? enabled = null,Object? createdAt = null,Object? values = null,Object? tags = null,Object? integers = null,Object? numbers = null,Object? rows = null,Object? metadata = freezed,Object? selection = null,Object? payload = freezed,}) {
  return _then(_ContractSampleEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,count: null == count ? _self.count : count // ignore: cast_nullable_to_non_nullable
as int,price: null == price ? _self.price : price // ignore: cast_nullable_to_non_nullable
as double,enabled: null == enabled ? _self.enabled : enabled // ignore: cast_nullable_to_non_nullable
as bool,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,values: null == values ? _self._values : values // ignore: cast_nullable_to_non_nullable
as List<dynamic>,tags: null == tags ? _self._tags : tags // ignore: cast_nullable_to_non_nullable
as List<String>,integers: null == integers ? _self._integers : integers // ignore: cast_nullable_to_non_nullable
as List<int>,numbers: null == numbers ? _self._numbers : numbers // ignore: cast_nullable_to_non_nullable
as List<num>,rows: null == rows ? _self._rows : rows // ignore: cast_nullable_to_non_nullable
as List<Map<String, dynamic>>,metadata: freezed == metadata ? _self._metadata : metadata // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>?,selection: null == selection ? _self._selection : selection // ignore: cast_nullable_to_non_nullable
as Set<dynamic>,payload: freezed == payload ? _self.payload : payload // ignore: cast_nullable_to_non_nullable
as dynamic,
  ));
}


}

// dart format on
