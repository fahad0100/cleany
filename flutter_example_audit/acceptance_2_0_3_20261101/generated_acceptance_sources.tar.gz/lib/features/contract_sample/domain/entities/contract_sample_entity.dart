// Defines immutable business data consumed by use cases and presentation.
import 'package:freezed_annotation/freezed_annotation.dart';
part 'contract_sample_entity.freezed.dart';

/// Defines immutable business data consumed by use cases and presentation.
@freezed
abstract class ContractSampleEntity with _$ContractSampleEntity {
  const factory ContractSampleEntity({
    required String id,
    required int count,
    required double price,
    required bool enabled,
    required DateTime createdAt,
    required List<dynamic> values,
    required List<String> tags,
    required List<int> integers,
    required List<num> numbers,
    required List<Map<String, dynamic>> rows,
    Map<String, dynamic>? metadata,
    required Set<dynamic> selection,
    dynamic payload,
  }) = _ContractSampleEntity;
}
