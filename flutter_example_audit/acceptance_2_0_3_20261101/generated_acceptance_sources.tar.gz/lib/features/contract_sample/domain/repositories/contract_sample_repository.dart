// Defines the domain repository contract returning an Entity or Failure in a Result.
import 'package:multiple_result/multiple_result.dart';
import 'package:cleany_store/core/errors/failure.dart';

import '../entities/contract_sample_entity.dart';

/// Defines the domain repository contract returning an Entity or Failure in a Result.
abstract interface class ContractSampleRepository {
  Future<Result<ContractSampleEntity, Failure>> fetch();
}
