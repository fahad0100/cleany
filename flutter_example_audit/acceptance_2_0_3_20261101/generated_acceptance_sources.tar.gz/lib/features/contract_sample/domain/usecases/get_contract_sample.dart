// Exposes one business operation through the domain repository contract.
import 'package:multiple_result/multiple_result.dart';
import 'package:cleany_store/core/errors/failure.dart';

import '../entities/contract_sample_entity.dart';
import '../repositories/contract_sample_repository.dart';

/// Exposes one business operation through the domain repository contract.
class GetContractSample {
  const GetContractSample(this._repository);
  final ContractSampleRepository _repository;
  Future<Result<ContractSampleEntity, Failure>> call() => _repository.fetch();
}
