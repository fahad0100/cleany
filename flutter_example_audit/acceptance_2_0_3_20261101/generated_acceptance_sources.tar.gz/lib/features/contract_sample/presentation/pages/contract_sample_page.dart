// Builds the feature page and renders loading, entity success, and failure states.

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/contract_sample_bloc.dart';
import '../bloc/contract_sample_state.dart';

/// Builds the feature page and renders loading, entity success, and failure states.
class ContractSamplePage extends StatelessWidget {
  const ContractSamplePage({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<ContractSampleBloc>();
    return Scaffold(
      appBar: AppBar(title: const Text('ContractSample')),
      body: BlocBuilder<ContractSampleBloc, ContractSampleState>(
        builder: (context, state) => switch (state) {
          ContractSampleInitial() => const SizedBox.shrink(),
          ContractSampleLoading() => const Center(
            child: CircularProgressIndicator(),
          ),
          ContractSampleSuccess(:final entity) => Center(
            child: Text(entity.id.toString()),
          ),
          ContractSampleFailure(:final failure) => Center(
            child: Text(failure.message),
          ),
        },
      ),
    );
  }
}
