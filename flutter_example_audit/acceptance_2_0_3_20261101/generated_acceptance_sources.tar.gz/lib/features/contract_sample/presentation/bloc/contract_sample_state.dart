// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:cleany_store/features/contract_sample/domain/entities/contract_sample_entity.dart';
import 'package:cleany_store/core/errors/failure.dart';
part 'contract_sample_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class ContractSampleState with _$ContractSampleState {
  const factory ContractSampleState.initial() = ContractSampleInitial;
  const factory ContractSampleState.loading() = ContractSampleLoading;
  const factory ContractSampleState.success(ContractSampleEntity entity) =
      ContractSampleSuccess;
  const factory ContractSampleState.failure(Failure failure) =
      ContractSampleFailure;
}
