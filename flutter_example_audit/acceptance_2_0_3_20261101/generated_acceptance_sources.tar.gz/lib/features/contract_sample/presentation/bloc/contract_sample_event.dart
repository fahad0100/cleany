// Defines the events that trigger operations in the generated Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part 'contract_sample_event.freezed.dart';

/// Defines the events that trigger operations in the generated Bloc.
@freezed
sealed class ContractSampleEvent with _$ContractSampleEvent {
  const factory ContractSampleEvent.requested() = ContractSampleRequested;
}
