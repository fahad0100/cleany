// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'contract_sample_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$ContractSampleState {





@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ContractSampleState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'ContractSampleState()';
}


}

/// @nodoc
class $ContractSampleStateCopyWith<$Res>  {
$ContractSampleStateCopyWith(ContractSampleState _, $Res Function(ContractSampleState) __);
}


/// Adds pattern-matching-related methods to [ContractSampleState].
extension ContractSampleStatePatterns on ContractSampleState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( ContractSampleInitial value)?  initial,TResult Function( ContractSampleLoading value)?  loading,TResult Function( ContractSampleSuccess value)?  success,TResult Function( ContractSampleFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case ContractSampleInitial() when initial != null:
return initial(_that);case ContractSampleLoading() when loading != null:
return loading(_that);case ContractSampleSuccess() when success != null:
return success(_that);case ContractSampleFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( ContractSampleInitial value)  initial,required TResult Function( ContractSampleLoading value)  loading,required TResult Function( ContractSampleSuccess value)  success,required TResult Function( ContractSampleFailure value)  failure,}){
final _that = this;
switch (_that) {
case ContractSampleInitial():
return initial(_that);case ContractSampleLoading():
return loading(_that);case ContractSampleSuccess():
return success(_that);case ContractSampleFailure():
return failure(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( ContractSampleInitial value)?  initial,TResult? Function( ContractSampleLoading value)?  loading,TResult? Function( ContractSampleSuccess value)?  success,TResult? Function( ContractSampleFailure value)?  failure,}){
final _that = this;
switch (_that) {
case ContractSampleInitial() when initial != null:
return initial(_that);case ContractSampleLoading() when loading != null:
return loading(_that);case ContractSampleSuccess() when success != null:
return success(_that);case ContractSampleFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( ContractSampleEntity entity)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case ContractSampleInitial() when initial != null:
return initial();case ContractSampleLoading() when loading != null:
return loading();case ContractSampleSuccess() when success != null:
return success(_that.entity);case ContractSampleFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( ContractSampleEntity entity)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case ContractSampleInitial():
return initial();case ContractSampleLoading():
return loading();case ContractSampleSuccess():
return success(_that.entity);case ContractSampleFailure():
return failure(_that.failure);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( ContractSampleEntity entity)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case ContractSampleInitial() when initial != null:
return initial();case ContractSampleLoading() when loading != null:
return loading();case ContractSampleSuccess() when success != null:
return success(_that.entity);case ContractSampleFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class ContractSampleInitial implements ContractSampleState {
  const ContractSampleInitial();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ContractSampleInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'ContractSampleState.initial()';
}


}




/// @nodoc


class ContractSampleLoading implements ContractSampleState {
  const ContractSampleLoading();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ContractSampleLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'ContractSampleState.loading()';
}


}




/// @nodoc


class ContractSampleSuccess implements ContractSampleState {
  const ContractSampleSuccess(this.entity);
  

 final  ContractSampleEntity entity;

/// Create a copy of ContractSampleState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ContractSampleSuccessCopyWith<ContractSampleSuccess> get copyWith => _$ContractSampleSuccessCopyWithImpl<ContractSampleSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ContractSampleSuccess&&(identical(other.entity, entity) || other.entity == entity));
}


@override
int get hashCode {
    return Object.hash(runtimeType,entity);
}

@override
String toString() {
    return 'ContractSampleState.success(entity: $entity)';
}


}

/// @nodoc
abstract mixin class $ContractSampleSuccessCopyWith<$Res> implements $ContractSampleStateCopyWith<$Res> {
  factory $ContractSampleSuccessCopyWith(ContractSampleSuccess value, $Res Function(ContractSampleSuccess) _then) = _$ContractSampleSuccessCopyWithImpl;
@useResult
$Res call({
 ContractSampleEntity entity
});


$ContractSampleEntityCopyWith<$Res> get entity;

}
/// @nodoc
class _$ContractSampleSuccessCopyWithImpl<$Res>
    implements $ContractSampleSuccessCopyWith<$Res> {
  _$ContractSampleSuccessCopyWithImpl(this._self, this._then);

  final ContractSampleSuccess _self;
  final $Res Function(ContractSampleSuccess) _then;

/// Create a copy of ContractSampleState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? entity = null,}) {
  return _then(ContractSampleSuccess(
null == entity ? _self.entity : entity // ignore: cast_nullable_to_non_nullable
as ContractSampleEntity,
  ));
}

/// Create a copy of ContractSampleState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$ContractSampleEntityCopyWith<$Res> get entity {
  
  return $ContractSampleEntityCopyWith<$Res>(_self.entity, (value) {
    return _then(_self.copyWith(entity: value));
  });
}
}

/// @nodoc


class ContractSampleFailure implements ContractSampleState {
  const ContractSampleFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of ContractSampleState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ContractSampleFailureCopyWith<ContractSampleFailure> get copyWith => _$ContractSampleFailureCopyWithImpl<ContractSampleFailure>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ContractSampleFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode {
    return Object.hash(runtimeType,failure);
}

@override
String toString() {
    return 'ContractSampleState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $ContractSampleFailureCopyWith<$Res> implements $ContractSampleStateCopyWith<$Res> {
  factory $ContractSampleFailureCopyWith(ContractSampleFailure value, $Res Function(ContractSampleFailure) _then) = _$ContractSampleFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});




}
/// @nodoc
class _$ContractSampleFailureCopyWithImpl<$Res>
    implements $ContractSampleFailureCopyWith<$Res> {
  _$ContractSampleFailureCopyWithImpl(this._self, this._then);

  final ContractSampleFailure _self;
  final $Res Function(ContractSampleFailure) _then;

/// Create a copy of ContractSampleState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(ContractSampleFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}


}

// dart format on
