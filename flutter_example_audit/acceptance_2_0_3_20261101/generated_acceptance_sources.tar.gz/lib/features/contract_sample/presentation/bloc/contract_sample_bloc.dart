// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cleany_store/features/contract_sample/domain/usecases/get_contract_sample.dart';

import 'contract_sample_state.dart';
import 'contract_sample_event.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class ContractSampleBloc
    extends Bloc<ContractSampleEvent, ContractSampleState> {
  final GetContractSample _getContractSample;
  ContractSampleBloc(this._getContractSample)
    : super(const ContractSampleState.initial()) {
    on<ContractSampleRequested>(_onRequested);
  }

  Future<void> _onRequested(
    ContractSampleRequested event,
    Emitter<ContractSampleState> emit,
  ) async {
    if (state is ContractSampleLoading) return;
    emit(const ContractSampleState.loading());
    final result = await _getContractSample();
    if (emit.isDone) return;
    result.when(
      (entity) => emit(ContractSampleState.success(entity)),
      (failure) => emit(ContractSampleState.failure(failure)),
    );
  }
}
