import 'package:multiple_result/multiple_result.dart';
import 'package:cleany_store/core/errors/failure.dart';
import 'package:cleany_store/core/errors/error_reporter.dart';
import 'package:cleany_store/core/errors/repository_guard.dart';

import '../../domain/entities/products_entity.dart';
import '../../domain/repositories/products_repository.dart';
import '../datasources/products_remote_data_source.dart';
import '../models/products_model.dart';

import 'package:cleany_store/core/network/failure_mapper.dart';
import 'package:cleany_store/features/users/domain/entities/users_entity.dart';

/// Owns JSON -> DTO -> Entity conversion and the single Failure boundary.
class ProductsRepositoryImpl implements ProductsRepository {
  const ProductsRepositoryImpl(
    this._remote, {
    this.reportError = reportUnexpectedError,
  });
  final ProductsRemoteDataSource _remote;
  final ErrorReporter reportError;
  ProductsEntity _entity(ProductsModel m) => ProductsEntity(
    id: m.id,
    title: m.title,
    price: m.price,
    description: m.description,
    category: m.category,
    image: m.image,
    rating: m.rating.rate,
    reviewCount: m.rating.count,
  );
  @override
  Future<Result<List<ProductsEntity>, Failure>> fetch() => repositoryGuard(
    () async => (await _remote.fetch())
        .map((j) => _entity(ProductsModel.fromJson(j)))
        .toList(),
    reportError,
  );
  @override
  Future<Result<ProductsEntity, Failure>> getFeaturedProduct() =>
      repositoryGuard(
        () async =>
            _entity(ProductsModel.fromJson(await _remote.getFeaturedProduct())),
        reportError,
      );

  /// Executes auditProductEntity; maps transport data and errors at this boundary.
  @override
  Future<Result<ProductsEntity, Failure>> auditProductEntity() async {
    try {
      final json = await _remote.auditProductEntity();
      final model = ProductsModel.fromJson(json);
      return Success(_mapAuditProductEntityEntity(model));
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) {
        // Reporting is observational and must preserve the original Result.
        try {
          reportError(error, stackTrace);
        } catch (_) {
          /* Keep the original failure. */
        }
      }
      return Error(failure);
    }
  }

  /// Complete this Data mapping using the existing Model and selected Entity.
  /// Its different shape is preserved; no guessed casts or schema edits occur.
  ProductsEntity _mapAuditProductEntityEntity(ProductsModel model) {
    throw UnimplementedError(
      'Map ProductsModel to ProductsEntity for auditProductEntity.',
    );
  }

  /// Executes auditUsersEntity; maps transport data and errors at this boundary.
  @override
  Future<Result<UsersEntity, Failure>> auditUsersEntity() async {
    try {
      final json = await _remote.auditUsersEntity();
      final model = ProductsModel.fromJson(json);
      return Success(_mapAuditUsersEntityEntity(model));
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) {
        // Reporting is observational and must preserve the original Result.
        try {
          reportError(error, stackTrace);
        } catch (_) {
          /* Keep the original failure. */
        }
      }
      return Error(failure);
    }
  }

  /// Complete this Data mapping using the existing Model and selected Entity.
  /// Its different shape is preserved; no guessed casts or schema edits occur.
  UsersEntity _mapAuditUsersEntityEntity(ProductsModel model) {
    throw UnimplementedError(
      'Map ProductsModel to UsersEntity for auditUsersEntity.',
    );
  }
}
