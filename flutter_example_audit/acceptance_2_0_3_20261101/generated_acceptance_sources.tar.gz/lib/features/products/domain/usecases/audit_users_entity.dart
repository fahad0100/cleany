// Exposes one business operation through the domain repository contract.
import 'package:multiple_result/multiple_result.dart';
import 'package:cleany_store/core/errors/failure.dart';

import '../repositories/products_repository.dart';

import 'package:cleany_store/features/users/domain/entities/users_entity.dart';

/// Exposes one business operation through the domain repository contract.
/// Runs auditUsersEntity through the feature's transport-independent contract.
class AuditUsersEntity {
  const AuditUsersEntity(this._repository);
  final ProductsRepository _repository;
  Future<Result<UsersEntity, Failure>> call() => _repository.auditUsersEntity();
}
