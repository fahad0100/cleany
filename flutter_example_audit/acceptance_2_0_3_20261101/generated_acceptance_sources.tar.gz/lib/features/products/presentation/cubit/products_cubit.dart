import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/usecases/get_products.dart';
import '../../domain/usecases/get_featured_product.dart';
import '../../domain/entities/products_entity.dart';

import 'package:cleany_store/core/state/use_case_state.dart';

import 'products_state.dart';

import 'package:cleany_store/features/products/domain/usecases/audit_product_entity.dart';
import 'package:cleany_store/core/errors/failure.dart';
import 'package:cleany_store/features/products/domain/usecases/audit_users_entity.dart';
import 'package:cleany_store/features/users/domain/entities/users_entity.dart';

/// Owns catalog loading, local presentation filters and the generated spotlight action.
class ProductsCubit extends Cubit<ProductsState> {
  ProductsCubit(
    this._getProducts, {
    required this.getFeaturedProductUseCase,
    this.auditProductEntityUseCase,
    this.auditUsersEntityUseCase,
  }) : super(const ProductsState.initial());
  final GetProducts _getProducts;
  final GetFeaturedProduct getFeaturedProductUseCase;
  Future<void> load() async {
    if (isClosed || state is ProductsLoading) return;
    emit(
      ProductsState.loading(
        query: state.query,
        category: state.category,
        priceAscending: state.priceAscending,
        getFeaturedProductStatus: state.getFeaturedProductStatus,
        auditProductEntityStatus: state.auditProductEntityStatus,
        auditUsersEntityStatus: state.auditUsersEntityStatus,
      ),
    );
    final result = await _getProducts();
    if (isClosed) return;
    result.when(
      (items) => emit(
        ProductsState.success(
          items,
          query: state.query,
          category: state.category,
          priceAscending: state.priceAscending,
          getFeaturedProductStatus: state.getFeaturedProductStatus,
          auditProductEntityStatus: state.auditProductEntityStatus,
          auditUsersEntityStatus: state.auditUsersEntityStatus,
        ),
      ),
      (failure) => emit(
        ProductsState.failure(
          failure,
          query: state.query,
          category: state.category,
          priceAscending: state.priceAscending,
          getFeaturedProductStatus: state.getFeaturedProductStatus,
          auditProductEntityStatus: state.auditProductEntityStatus,
          auditUsersEntityStatus: state.auditUsersEntityStatus,
        ),
      ),
    );
  }

  void search(String query) {
    if (!isClosed) emit(state.copyWith(query: query));
  }

  void selectCategory(String? category) {
    if (!isClosed) emit(state.copyWith(category: category));
  }

  void toggleSort() {
    if (!isClosed) emit(state.copyWith(priceAscending: !state.priceAscending));
  }

  List<ProductsEntity> get visibleProducts {
    final current = state;
    if (current is! ProductsSuccess) return [];
    final result = current.products
        .where(
          (p) =>
              (state.category == null || p.category == state.category) &&
              p.title.toLowerCase().contains(state.query.toLowerCase()),
        )
        .toList();
    if (state.priceAscending) result.sort((a, b) => a.price.compareTo(b.price));
    return result;
  }

  Future<void> getFeaturedProduct() async {
    if (isClosed ||
        state.getFeaturedProductStatus is UseCaseLoading<ProductsEntity>) {
      return;
    }
    emit(
      state.copyWith(getFeaturedProductStatus: const UseCaseState.loading()),
    );
    final result = await getFeaturedProductUseCase();
    if (isClosed) return;
    result.when(
      (p) => emit(
        state.copyWith(getFeaturedProductStatus: UseCaseState.success(p)),
      ),
      (f) => emit(
        state.copyWith(getFeaturedProductStatus: UseCaseState.failure(f)),
      ),
    );
  }

  /// Optional for existing manual construction; central DI always supplies this action.
  final AuditProductEntity? auditProductEntityUseCase;

  /// Updates only auditProductEntityStatus; other actions keep their current state.
  Future<void> auditProductEntity() async {
    if (isClosed ||
        state.auditProductEntityStatus is UseCaseLoading<ProductsEntity>) {
      return;
    }
    emit(
      state.copyWith(
        auditProductEntityStatus: const UseCaseState<ProductsEntity>.loading(),
      ),
    );
    final useCase = auditProductEntityUseCase;
    if (useCase == null) {
      emit(
        state.copyWith(
          auditProductEntityStatus: const UseCaseState<ProductsEntity>.failure(
            UnexpectedFailure('This action is unavailable.'),
          ),
        ),
      );
      return;
    }
    final result = await useCase();
    if (isClosed) {
      return;
    }
    result.when(
      (entity) => emit(
        state.copyWith(
          auditProductEntityStatus: UseCaseState<ProductsEntity>.success(
            entity,
          ),
        ),
      ),
      (failure) => emit(
        state.copyWith(
          auditProductEntityStatus: UseCaseState<ProductsEntity>.failure(
            failure,
          ),
        ),
      ),
    );
  }

  /// Optional for existing manual construction; central DI always supplies this action.
  final AuditUsersEntity? auditUsersEntityUseCase;

  /// Updates only auditUsersEntityStatus; other actions keep their current state.
  Future<void> auditUsersEntity() async {
    if (isClosed ||
        state.auditUsersEntityStatus is UseCaseLoading<UsersEntity>) {
      return;
    }
    emit(
      state.copyWith(
        auditUsersEntityStatus: const UseCaseState<UsersEntity>.loading(),
      ),
    );
    final useCase = auditUsersEntityUseCase;
    if (useCase == null) {
      emit(
        state.copyWith(
          auditUsersEntityStatus: const UseCaseState<UsersEntity>.failure(
            UnexpectedFailure('This action is unavailable.'),
          ),
        ),
      );
      return;
    }
    final result = await useCase();
    if (isClosed) {
      return;
    }
    result.when(
      (entity) => emit(
        state.copyWith(
          auditUsersEntityStatus: UseCaseState<UsersEntity>.success(entity),
        ),
      ),
      (failure) => emit(
        state.copyWith(
          auditUsersEntityStatus: UseCaseState<UsersEntity>.failure(failure),
        ),
      ),
    );
  }
}
