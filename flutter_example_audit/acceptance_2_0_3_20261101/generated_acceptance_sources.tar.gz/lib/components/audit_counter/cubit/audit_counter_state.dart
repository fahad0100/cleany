// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part 'audit_counter_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class AuditCounterState with _$AuditCounterState {
  const factory AuditCounterState.initial() = AuditCounterInitial;
  const factory AuditCounterState.updated(int value) = AuditCounterUpdated;
}
