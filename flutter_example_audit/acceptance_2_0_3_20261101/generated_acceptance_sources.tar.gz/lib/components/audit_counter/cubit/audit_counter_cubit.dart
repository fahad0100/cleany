// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';

import 'audit_counter_state.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class AuditCounterCubit extends Cubit<AuditCounterState> {
  AuditCounterCubit() : super(const AuditCounterState.initial());

  void update(int value) {
    if (!isClosed) emit(AuditCounterState.updated(value));
  }
}
