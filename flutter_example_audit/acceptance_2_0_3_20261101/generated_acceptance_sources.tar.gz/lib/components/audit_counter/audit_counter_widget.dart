// Builds a reusable widget and renders its optional presentation state.
// Cleany component layout: flat. Widget lives at the component root.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'cubit/audit_counter_cubit.dart';
import 'cubit/audit_counter_state.dart';

/// Builds a reusable widget and renders its optional presentation state.
class AuditCounterWidget extends StatelessWidget {
  const AuditCounterWidget({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<AuditCounterCubit>();
    return BlocBuilder<AuditCounterCubit, AuditCounterState>(
      builder: (context, state) => switch (state) {
        AuditCounterInitial() => const SizedBox.shrink(),
        AuditCounterUpdated(:final value) => Text('$value'),
      },
    );
  }
}
