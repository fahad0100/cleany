// Declares API endpoints returning raw JSON; Retrofit generates the HTTP implementation.
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
part 'contract_sample_api.g.dart';

/// Declares API endpoints returning raw JSON; Retrofit generates the HTTP implementation.
@RestApi()
abstract class ContractSampleApi {
  factory ContractSampleApi(Dio dio, {String? baseUrl}) = _ContractSampleApi;
  @GET("/contract_sample")
  Future<Map<String, Object?>> fetch();
}
