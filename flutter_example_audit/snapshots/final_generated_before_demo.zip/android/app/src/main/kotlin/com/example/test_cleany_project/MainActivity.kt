package com.example.test_cleany_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
