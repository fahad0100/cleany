import com.android.build.gradle.AppExtension

val android = project.extensions.getByType(AppExtension::class.java)

android.apply {
    flavorDimensions("flavor-type")

    productFlavors {
        create("dev") {
            dimension = "flavor-type"
            applicationId = "com.example.testCleanyProject.dev"
            resValue(type = "string", name = "app_name", value = "test_cleany_project Dev")
        }
        create("uat") {
            dimension = "flavor-type"
            applicationId = "com.example.testCleanyProject.uat"
            resValue(type = "string", name = "app_name", value = "test_cleany_project UAT")
        }
        create("prod") {
            dimension = "flavor-type"
            applicationId = "com.example.testCleanyProject"
            resValue(type = "string", name = "app_name", value = "test_cleany_project")
        }
    }

    buildFeatures.resValues = true
}