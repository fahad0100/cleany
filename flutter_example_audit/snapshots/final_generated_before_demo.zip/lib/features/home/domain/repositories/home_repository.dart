// Defines the domain repository contract returning an Entity or Failure in a Result.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';

import '../entities/home_entity.dart';

/// Defines the domain repository contract returning an Entity or Failure in a Result.
abstract interface class HomeRepository {
  Future<Result<HomeEntity, Failure>> fetch();
}
