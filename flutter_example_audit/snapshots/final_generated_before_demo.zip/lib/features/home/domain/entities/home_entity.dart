// Defines immutable business data consumed by use cases and presentation.
import 'package:freezed_annotation/freezed_annotation.dart';
part 'home_entity.freezed.dart';

/// Defines immutable business data consumed by use cases and presentation.
@freezed
abstract class HomeEntity with _$HomeEntity {
  const factory HomeEntity({
    required String id,
    String? title,
    required int visits,
  }) = _HomeEntity;
}
