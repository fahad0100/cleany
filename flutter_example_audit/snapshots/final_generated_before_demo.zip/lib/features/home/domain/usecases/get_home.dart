// Exposes one business operation through the domain repository contract.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';

import '../entities/home_entity.dart';
import '../repositories/home_repository.dart';

/// Exposes one business operation through the domain repository contract.
class GetHome {
  const GetHome(this._repository);
  final HomeRepository _repository;
  Future<Result<HomeEntity, Failure>> call() => _repository.fetch();
}
