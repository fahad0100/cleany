// Fetches raw JSON and propagates exceptions to the repository.
import 'package:test_cleany_project/core/network/retrofit/home_api.dart';

/// Fetches raw JSON and propagates exceptions to the repository.
class HomeRemoteDataSource {
  const HomeRemoteDataSource(this._api);
  final HomeApi _api;
  // Raw JSON only. Conversion and Failure mapping belong to the repository.
  Future<Map<String, dynamic>> fetch() => _api.fetch();
}
