// Defines the API data model and its generated JSON serialization.
// Freezed forwards JSON annotations to the generated properties.
// ignore_for_file: invalid_annotation_target
import 'package:freezed_annotation/freezed_annotation.dart';
part 'home_model.freezed.dart';
part 'home_model.g.dart';

/// Defines the API data model and its generated JSON serialization.
@freezed
abstract class HomeModel with _$HomeModel {
  const factory HomeModel({
    required String id,
    String? title,
    required int visits,
  }) = _HomeModel;
  factory HomeModel.fromJson(Map<String, dynamic> json) =>
      _$HomeModelFromJson(json);
}
