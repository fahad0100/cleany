// Converts JSON/models into entities and returns Success or Failure exactly once.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
import 'package:test_cleany_project/core/errors/error_reporter.dart';
import 'package:test_cleany_project/core/network/failure_mapper.dart';
import 'package:test_cleany_project/features/home/domain/entities/home_entity.dart';
import 'package:test_cleany_project/features/home/domain/repositories/home_repository.dart';

import '../datasources/home_remote_data_source.dart';
import '../models/home_model.dart';

/// Converts JSON/models into entities and returns Success or Failure exactly once.
class HomeRepositoryImpl implements HomeRepository {
  const HomeRepositoryImpl(
    this._remote, {
    this.reportError = reportUnexpectedError,
  });
  final HomeRemoteDataSource _remote;
  final ErrorReporter reportError;
  @override
  Future<Result<HomeEntity, Failure>> fetch() async {
    try {
      final json = await _remote.fetch();
      final model = HomeModel.fromJson(json);
      return Success(
        HomeEntity(id: model.id, title: model.title, visits: model.visits),
      );
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) reportError(error, stackTrace);
      return Error(failure);
    }
  }
}
