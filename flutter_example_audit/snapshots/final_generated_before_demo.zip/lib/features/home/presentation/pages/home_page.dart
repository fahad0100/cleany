// Builds the feature page and renders loading, entity success, and failure states.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubit/home_cubit.dart';
import '../cubit/home_state.dart';

/// Builds the feature page and renders loading, entity success, and failure states.
class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<HomeCubit>();
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) => switch (state) {
          HomeInitial() => const SizedBox.shrink(),
          HomeLoading() => const Center(child: CircularProgressIndicator()),
          HomeSuccess(:final entity) => Center(
            child: Text(entity.id.toString()),
          ),
          HomeFailure(:final failure) => Center(child: Text(failure.message)),
        },
      ),
    );
  }
}
