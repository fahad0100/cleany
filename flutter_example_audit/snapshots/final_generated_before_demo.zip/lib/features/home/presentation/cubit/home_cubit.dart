// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_cleany_project/features/home/domain/usecases/get_home.dart';

import 'home_state.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class HomeCubit extends Cubit<HomeState> {
  final GetHome _getHome;
  HomeCubit(this._getHome) : super(const HomeState.initial());

  Future<void> load() async {
    if (isClosed || state is HomeLoading) return;
    emit(const HomeState.loading());
    final result = await _getHome();
    if (isClosed) return;
    result.when(
      (entity) => emit(HomeState.success(entity)),
      (failure) => emit(HomeState.failure(failure)),
    );
  }
}
