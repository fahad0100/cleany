// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:test_cleany_project/features/home/domain/entities/home_entity.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
part 'home_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class HomeState with _$HomeState {
  const factory HomeState.initial() = HomeInitial;
  const factory HomeState.loading() = HomeLoading;
  const factory HomeState.success(HomeEntity entity) = HomeSuccess;
  const factory HomeState.failure(Failure failure) = HomeFailure;
}
