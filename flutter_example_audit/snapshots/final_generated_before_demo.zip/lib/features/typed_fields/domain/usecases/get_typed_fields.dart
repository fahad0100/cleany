// Exposes one business operation through the domain repository contract.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';

import '../entities/typed_fields_entity.dart';
import '../repositories/typed_fields_repository.dart';

/// Exposes one business operation through the domain repository contract.
class GetTypedFields {
  const GetTypedFields(this._repository);
  final TypedFieldsRepository _repository;
  Future<Result<TypedFieldsEntity, Failure>> call() => _repository.fetch();
}
