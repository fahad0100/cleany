// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'typed_fields_entity.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$TypedFieldsEntity {

 String get id; double get price; bool get enabled; DateTime get createdAt; List<String>? get tags; List<int>? get counts; int get quantity;
/// Create a copy of TypedFieldsEntity
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TypedFieldsEntityCopyWith<TypedFieldsEntity> get copyWith => _$TypedFieldsEntityCopyWithImpl<TypedFieldsEntity>(this as TypedFieldsEntity, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as TypedFieldsEntity;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is TypedFieldsEntity&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.price, _this.price) || other.price == _this.price)&&(identical(other.enabled, _this.enabled) || other.enabled == _this.enabled)&&(identical(other.createdAt, _this.createdAt) || other.createdAt == _this.createdAt)&&const DeepCollectionEquality().equals(other.tags, _this.tags)&&const DeepCollectionEquality().equals(other.counts, _this.counts)&&(identical(other.quantity, _this.quantity) || other.quantity == _this.quantity));
}


@override
int get hashCode {
  final _this = this as TypedFieldsEntity;
  return Object.hash(runtimeType,_this.id,_this.price,_this.enabled,_this.createdAt,const DeepCollectionEquality().hash(_this.tags),const DeepCollectionEquality().hash(_this.counts),_this.quantity);
}

@override
String toString() {
  final _this = this as TypedFieldsEntity;
  return 'TypedFieldsEntity(id: ${_this.id}, price: ${_this.price}, enabled: ${_this.enabled}, createdAt: ${_this.createdAt}, tags: ${_this.tags}, counts: ${_this.counts}, quantity: ${_this.quantity})';
}


}

/// @nodoc
abstract mixin class $TypedFieldsEntityCopyWith<$Res>  {
  factory $TypedFieldsEntityCopyWith(TypedFieldsEntity value, $Res Function(TypedFieldsEntity) _then) = _$TypedFieldsEntityCopyWithImpl;
@useResult
$Res call({
 String id, double price, bool enabled, DateTime createdAt, List<String>? tags, List<int>? counts, int quantity
});




}
/// @nodoc
class _$TypedFieldsEntityCopyWithImpl<$Res>
    implements $TypedFieldsEntityCopyWith<$Res> {
  _$TypedFieldsEntityCopyWithImpl(this._self, this._then);

  final TypedFieldsEntity _self;
  final $Res Function(TypedFieldsEntity) _then;

/// Create a copy of TypedFieldsEntity
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? price = null,Object? enabled = null,Object? createdAt = null,Object? tags = freezed,Object? counts = freezed,Object? quantity = null,}) {
  return _then(TypedFieldsEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,price: null == price ? _self.price : price // ignore: cast_nullable_to_non_nullable
as double,enabled: null == enabled ? _self.enabled : enabled // ignore: cast_nullable_to_non_nullable
as bool,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,tags: freezed == tags ? _self.tags : tags // ignore: cast_nullable_to_non_nullable
as List<String>?,counts: freezed == counts ? _self.counts : counts // ignore: cast_nullable_to_non_nullable
as List<int>?,quantity: null == quantity ? _self.quantity : quantity // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [TypedFieldsEntity].
extension TypedFieldsEntityPatterns on TypedFieldsEntity {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _TypedFieldsEntity value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _TypedFieldsEntity() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _TypedFieldsEntity value)  $default,){
final _that = this;
switch (_that) {
case _TypedFieldsEntity():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _TypedFieldsEntity value)?  $default,){
final _that = this;
switch (_that) {
case _TypedFieldsEntity() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  double price,  bool enabled,  DateTime createdAt,  List<String>? tags,  List<int>? counts,  int quantity)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _TypedFieldsEntity() when $default != null:
return $default(_that.id,_that.price,_that.enabled,_that.createdAt,_that.tags,_that.counts,_that.quantity);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  double price,  bool enabled,  DateTime createdAt,  List<String>? tags,  List<int>? counts,  int quantity)  $default,) {final _that = this;
switch (_that) {
case _TypedFieldsEntity():
return $default(_that.id,_that.price,_that.enabled,_that.createdAt,_that.tags,_that.counts,_that.quantity);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  double price,  bool enabled,  DateTime createdAt,  List<String>? tags,  List<int>? counts,  int quantity)?  $default,) {final _that = this;
switch (_that) {
case _TypedFieldsEntity() when $default != null:
return $default(_that.id,_that.price,_that.enabled,_that.createdAt,_that.tags,_that.counts,_that.quantity);case _:
  return null;

}
}

}

/// @nodoc


class _TypedFieldsEntity implements TypedFieldsEntity {
  const _TypedFieldsEntity({required this.id, required this.price, required this.enabled, required this.createdAt,  List<String>? tags,  List<int>? counts, required this.quantity}): _tags = tags,_counts = counts;
  

@override final  String id;
@override final  double price;
@override final  bool enabled;
@override final  DateTime createdAt;
 final  List<String>? _tags;
@override List<String>? get tags {
  final value = _tags;
  if (value == null) return null;
  if (_tags is EqualUnmodifiableListView) return _tags;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(value);
}

 final  List<int>? _counts;
@override List<int>? get counts {
  final value = _counts;
  if (value == null) return null;
  if (_counts is EqualUnmodifiableListView) return _counts;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(value);
}

@override final  int quantity;

/// Create a copy of TypedFieldsEntity
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$TypedFieldsEntityCopyWith<_TypedFieldsEntity> get copyWith => __$TypedFieldsEntityCopyWithImpl<_TypedFieldsEntity>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _TypedFieldsEntity&&(identical(other.id, id) || other.id == id)&&(identical(other.price, price) || other.price == price)&&(identical(other.enabled, enabled) || other.enabled == enabled)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&const DeepCollectionEquality().equals(other.tags, _tags)&&const DeepCollectionEquality().equals(other.counts, _counts)&&(identical(other.quantity, quantity) || other.quantity == quantity));
}


@override
int get hashCode {
    return Object.hash(runtimeType,id,price,enabled,createdAt,const DeepCollectionEquality().hash(_tags),const DeepCollectionEquality().hash(_counts),quantity);
}

@override
String toString() {
    return 'TypedFieldsEntity(id: $id, price: $price, enabled: $enabled, createdAt: $createdAt, tags: $tags, counts: $counts, quantity: $quantity)';
}


}

/// @nodoc
abstract mixin class _$TypedFieldsEntityCopyWith<$Res> implements $TypedFieldsEntityCopyWith<$Res> {
  factory _$TypedFieldsEntityCopyWith(_TypedFieldsEntity value, $Res Function(_TypedFieldsEntity) _then) = __$TypedFieldsEntityCopyWithImpl;
@override @useResult
$Res call({
 String id, double price, bool enabled, DateTime createdAt, List<String>? tags, List<int>? counts, int quantity
});




}
/// @nodoc
class __$TypedFieldsEntityCopyWithImpl<$Res>
    implements _$TypedFieldsEntityCopyWith<$Res> {
  __$TypedFieldsEntityCopyWithImpl(this._self, this._then);

  final _TypedFieldsEntity _self;
  final $Res Function(_TypedFieldsEntity) _then;

/// Create a copy of TypedFieldsEntity
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? price = null,Object? enabled = null,Object? createdAt = null,Object? tags = freezed,Object? counts = freezed,Object? quantity = null,}) {
  return _then(_TypedFieldsEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,price: null == price ? _self.price : price // ignore: cast_nullable_to_non_nullable
as double,enabled: null == enabled ? _self.enabled : enabled // ignore: cast_nullable_to_non_nullable
as bool,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,tags: freezed == tags ? _self._tags : tags // ignore: cast_nullable_to_non_nullable
as List<String>?,counts: freezed == counts ? _self._counts : counts // ignore: cast_nullable_to_non_nullable
as List<int>?,quantity: null == quantity ? _self.quantity : quantity // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
