// Defines immutable business data consumed by use cases and presentation.
import 'package:freezed_annotation/freezed_annotation.dart';
part 'typed_fields_entity.freezed.dart';

/// Defines immutable business data consumed by use cases and presentation.
@freezed
abstract class TypedFieldsEntity with _$TypedFieldsEntity {
  const factory TypedFieldsEntity({
    required String id,
    required double price,
    required bool enabled,
    required DateTime createdAt,
    List<String>? tags,
    List<int>? counts,
    required int quantity,
  }) = _TypedFieldsEntity;
}
