// Converts JSON/models into entities and returns Success or Failure exactly once.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
import 'package:test_cleany_project/core/errors/error_reporter.dart';
import 'package:test_cleany_project/core/network/failure_mapper.dart';
import 'package:test_cleany_project/features/typed_fields/domain/entities/typed_fields_entity.dart';
import 'package:test_cleany_project/features/typed_fields/domain/repositories/typed_fields_repository.dart';

import '../datasources/typed_fields_remote_data_source.dart';
import '../models/typed_fields_model.dart';

/// Converts JSON/models into entities and returns Success or Failure exactly once.
class TypedFieldsRepositoryImpl implements TypedFieldsRepository {
  const TypedFieldsRepositoryImpl(
    this._remote, {
    this.reportError = reportUnexpectedError,
  });
  final TypedFieldsRemoteDataSource _remote;
  final ErrorReporter reportError;
  @override
  Future<Result<TypedFieldsEntity, Failure>> fetch() async {
    try {
      final json = await _remote.fetch();
      final model = TypedFieldsModel.fromJson(json);
      return Success(
        TypedFieldsEntity(
          id: model.id,
          price: model.price,
          enabled: model.enabled,
          createdAt: model.createdAt,
          tags: model.tags,
          counts: model.counts,
          quantity: model.quantity,
        ),
      );
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) reportError(error, stackTrace);
      return Error(failure);
    }
  }
}
