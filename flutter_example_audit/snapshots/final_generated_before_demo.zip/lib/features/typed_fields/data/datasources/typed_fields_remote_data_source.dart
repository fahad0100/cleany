// Fetches raw JSON and propagates exceptions to the repository.
import 'package:test_cleany_project/core/network/retrofit/typed_fields_api.dart';

/// Fetches raw JSON and propagates exceptions to the repository.
class TypedFieldsRemoteDataSource {
  const TypedFieldsRemoteDataSource(this._api);
  final TypedFieldsApi _api;
  // Raw JSON only. Conversion and Failure mapping belong to the repository.
  Future<Map<String, dynamic>> fetch() => _api.fetch();
}
