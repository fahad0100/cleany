// Defines the API data model and its generated JSON serialization.
// Freezed forwards JSON annotations to the generated properties.
// ignore_for_file: invalid_annotation_target
import 'package:freezed_annotation/freezed_annotation.dart';
part 'typed_fields_model.freezed.dart';
part 'typed_fields_model.g.dart';

/// Defines the API data model and its generated JSON serialization.
@freezed
abstract class TypedFieldsModel with _$TypedFieldsModel {
  const factory TypedFieldsModel({
    required String id,
    required double price,
    required bool enabled,
    @JsonKey(name: "created_at") required DateTime createdAt,
    List<String>? tags,
    List<int>? counts,
    required int quantity,
  }) = _TypedFieldsModel;
  factory TypedFieldsModel.fromJson(Map<String, dynamic> json) =>
      _$TypedFieldsModelFromJson(json);
}
