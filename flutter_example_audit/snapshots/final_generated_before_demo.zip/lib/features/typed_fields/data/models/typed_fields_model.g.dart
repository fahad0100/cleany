// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'typed_fields_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_TypedFieldsModel _$TypedFieldsModelFromJson(Map<String, dynamic> json) =>
    _TypedFieldsModel(
      id: json['id'] as String,
      price: (json['price'] as num).toDouble(),
      enabled: json['enabled'] as bool,
      createdAt: DateTime.parse(json['created_at'] as String),
      tags: (json['tags'] as List<dynamic>?)?.map((e) => e as String).toList(),
      counts: (json['counts'] as List<dynamic>?)
          ?.map((e) => (e as num).toInt())
          .toList(),
      quantity: (json['quantity'] as num).toInt(),
    );

Map<String, dynamic> _$TypedFieldsModelToJson(_TypedFieldsModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'price': instance.price,
      'enabled': instance.enabled,
      'created_at': instance.createdAt.toIso8601String(),
      'tags': instance.tags,
      'counts': instance.counts,
      'quantity': instance.quantity,
    };
