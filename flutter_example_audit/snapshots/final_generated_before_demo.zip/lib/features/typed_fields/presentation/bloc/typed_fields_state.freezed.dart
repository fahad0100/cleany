// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'typed_fields_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$TypedFieldsState {





@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is TypedFieldsState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'TypedFieldsState()';
}


}

/// @nodoc
class $TypedFieldsStateCopyWith<$Res>  {
$TypedFieldsStateCopyWith(TypedFieldsState _, $Res Function(TypedFieldsState) __);
}


/// Adds pattern-matching-related methods to [TypedFieldsState].
extension TypedFieldsStatePatterns on TypedFieldsState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( TypedFieldsInitial value)?  initial,TResult Function( TypedFieldsLoading value)?  loading,TResult Function( TypedFieldsSuccess value)?  success,TResult Function( TypedFieldsFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case TypedFieldsInitial() when initial != null:
return initial(_that);case TypedFieldsLoading() when loading != null:
return loading(_that);case TypedFieldsSuccess() when success != null:
return success(_that);case TypedFieldsFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( TypedFieldsInitial value)  initial,required TResult Function( TypedFieldsLoading value)  loading,required TResult Function( TypedFieldsSuccess value)  success,required TResult Function( TypedFieldsFailure value)  failure,}){
final _that = this;
switch (_that) {
case TypedFieldsInitial():
return initial(_that);case TypedFieldsLoading():
return loading(_that);case TypedFieldsSuccess():
return success(_that);case TypedFieldsFailure():
return failure(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( TypedFieldsInitial value)?  initial,TResult? Function( TypedFieldsLoading value)?  loading,TResult? Function( TypedFieldsSuccess value)?  success,TResult? Function( TypedFieldsFailure value)?  failure,}){
final _that = this;
switch (_that) {
case TypedFieldsInitial() when initial != null:
return initial(_that);case TypedFieldsLoading() when loading != null:
return loading(_that);case TypedFieldsSuccess() when success != null:
return success(_that);case TypedFieldsFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( TypedFieldsEntity entity)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case TypedFieldsInitial() when initial != null:
return initial();case TypedFieldsLoading() when loading != null:
return loading();case TypedFieldsSuccess() when success != null:
return success(_that.entity);case TypedFieldsFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( TypedFieldsEntity entity)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case TypedFieldsInitial():
return initial();case TypedFieldsLoading():
return loading();case TypedFieldsSuccess():
return success(_that.entity);case TypedFieldsFailure():
return failure(_that.failure);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( TypedFieldsEntity entity)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case TypedFieldsInitial() when initial != null:
return initial();case TypedFieldsLoading() when loading != null:
return loading();case TypedFieldsSuccess() when success != null:
return success(_that.entity);case TypedFieldsFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class TypedFieldsInitial implements TypedFieldsState {
  const TypedFieldsInitial();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is TypedFieldsInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'TypedFieldsState.initial()';
}


}




/// @nodoc


class TypedFieldsLoading implements TypedFieldsState {
  const TypedFieldsLoading();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is TypedFieldsLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'TypedFieldsState.loading()';
}


}




/// @nodoc


class TypedFieldsSuccess implements TypedFieldsState {
  const TypedFieldsSuccess(this.entity);
  

 final  TypedFieldsEntity entity;

/// Create a copy of TypedFieldsState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TypedFieldsSuccessCopyWith<TypedFieldsSuccess> get copyWith => _$TypedFieldsSuccessCopyWithImpl<TypedFieldsSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is TypedFieldsSuccess&&(identical(other.entity, entity) || other.entity == entity));
}


@override
int get hashCode {
    return Object.hash(runtimeType,entity);
}

@override
String toString() {
    return 'TypedFieldsState.success(entity: $entity)';
}


}

/// @nodoc
abstract mixin class $TypedFieldsSuccessCopyWith<$Res> implements $TypedFieldsStateCopyWith<$Res> {
  factory $TypedFieldsSuccessCopyWith(TypedFieldsSuccess value, $Res Function(TypedFieldsSuccess) _then) = _$TypedFieldsSuccessCopyWithImpl;
@useResult
$Res call({
 TypedFieldsEntity entity
});


$TypedFieldsEntityCopyWith<$Res> get entity;

}
/// @nodoc
class _$TypedFieldsSuccessCopyWithImpl<$Res>
    implements $TypedFieldsSuccessCopyWith<$Res> {
  _$TypedFieldsSuccessCopyWithImpl(this._self, this._then);

  final TypedFieldsSuccess _self;
  final $Res Function(TypedFieldsSuccess) _then;

/// Create a copy of TypedFieldsState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? entity = null,}) {
  return _then(TypedFieldsSuccess(
null == entity ? _self.entity : entity // ignore: cast_nullable_to_non_nullable
as TypedFieldsEntity,
  ));
}

/// Create a copy of TypedFieldsState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$TypedFieldsEntityCopyWith<$Res> get entity {
  
  return $TypedFieldsEntityCopyWith<$Res>(_self.entity, (value) {
    return _then(_self.copyWith(entity: value));
  });
}
}

/// @nodoc


class TypedFieldsFailure implements TypedFieldsState {
  const TypedFieldsFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of TypedFieldsState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TypedFieldsFailureCopyWith<TypedFieldsFailure> get copyWith => _$TypedFieldsFailureCopyWithImpl<TypedFieldsFailure>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is TypedFieldsFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode {
    return Object.hash(runtimeType,failure);
}

@override
String toString() {
    return 'TypedFieldsState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $TypedFieldsFailureCopyWith<$Res> implements $TypedFieldsStateCopyWith<$Res> {
  factory $TypedFieldsFailureCopyWith(TypedFieldsFailure value, $Res Function(TypedFieldsFailure) _then) = _$TypedFieldsFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});




}
/// @nodoc
class _$TypedFieldsFailureCopyWithImpl<$Res>
    implements $TypedFieldsFailureCopyWith<$Res> {
  _$TypedFieldsFailureCopyWithImpl(this._self, this._then);

  final TypedFieldsFailure _self;
  final $Res Function(TypedFieldsFailure) _then;

/// Create a copy of TypedFieldsState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(TypedFieldsFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}


}

// dart format on
