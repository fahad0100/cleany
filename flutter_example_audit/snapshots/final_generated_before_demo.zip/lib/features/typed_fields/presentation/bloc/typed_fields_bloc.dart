// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_cleany_project/features/typed_fields/domain/usecases/get_typed_fields.dart';

import 'typed_fields_state.dart';
import 'typed_fields_event.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class TypedFieldsBloc extends Bloc<TypedFieldsEvent, TypedFieldsState> {
  final GetTypedFields _getTypedFields;
  TypedFieldsBloc(this._getTypedFields)
    : super(const TypedFieldsState.initial()) {
    on<TypedFieldsRequested>(_onRequested);
  }

  Future<void> _onRequested(
    TypedFieldsRequested event,
    Emitter<TypedFieldsState> emit,
  ) async {
    if (state is TypedFieldsLoading) return;
    emit(const TypedFieldsState.loading());
    final result = await _getTypedFields();
    if (emit.isDone) return;
    result.when(
      (entity) => emit(TypedFieldsState.success(entity)),
      (failure) => emit(TypedFieldsState.failure(failure)),
    );
  }
}
