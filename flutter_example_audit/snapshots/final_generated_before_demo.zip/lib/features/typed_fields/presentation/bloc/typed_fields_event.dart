// Defines the events that trigger operations in the generated Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part 'typed_fields_event.freezed.dart';

/// Defines the events that trigger operations in the generated Bloc.
@freezed
sealed class TypedFieldsEvent with _$TypedFieldsEvent {
  const factory TypedFieldsEvent.requested() = TypedFieldsRequested;
}
