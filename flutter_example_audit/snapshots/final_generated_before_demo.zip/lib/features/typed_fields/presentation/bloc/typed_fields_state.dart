// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:test_cleany_project/features/typed_fields/domain/entities/typed_fields_entity.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
part 'typed_fields_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class TypedFieldsState with _$TypedFieldsState {
  const factory TypedFieldsState.initial() = TypedFieldsInitial;
  const factory TypedFieldsState.loading() = TypedFieldsLoading;
  const factory TypedFieldsState.success(TypedFieldsEntity entity) =
      TypedFieldsSuccess;
  const factory TypedFieldsState.failure(Failure failure) = TypedFieldsFailure;
}
