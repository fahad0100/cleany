// Builds the feature page and renders loading, entity success, and failure states.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/typed_fields_bloc.dart';
import '../bloc/typed_fields_state.dart';

/// Builds the feature page and renders loading, entity success, and failure states.
class TypedFieldsPage extends StatelessWidget {
  const TypedFieldsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<TypedFieldsBloc>();
    return Scaffold(
      appBar: AppBar(title: const Text('TypedFields')),
      body: BlocBuilder<TypedFieldsBloc, TypedFieldsState>(
        builder: (context, state) => switch (state) {
          TypedFieldsInitial() => const SizedBox.shrink(),
          TypedFieldsLoading() => const Center(
            child: CircularProgressIndicator(),
          ),
          TypedFieldsSuccess(:final entity) => Center(
            child: Text(entity.id.toString()),
          ),
          TypedFieldsFailure(:final failure) => Center(
            child: Text(failure.message),
          ),
        },
      ),
    );
  }
}
