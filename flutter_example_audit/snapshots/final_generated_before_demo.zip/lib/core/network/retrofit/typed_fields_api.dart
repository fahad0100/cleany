// Declares API endpoints returning raw JSON; Retrofit generates the HTTP implementation.
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
part 'typed_fields_api.g.dart';

/// Declares API endpoints returning raw JSON; Retrofit generates the HTTP implementation.
@RestApi()
abstract class TypedFieldsApi {
  factory TypedFieldsApi(Dio dio, {String? baseUrl}) = _TypedFieldsApi;
  @GET("/typed_fields")
  Future<Map<String, Object?>> fetch();
}
