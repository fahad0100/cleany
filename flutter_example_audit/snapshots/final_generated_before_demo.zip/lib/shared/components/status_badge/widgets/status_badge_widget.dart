// Builds a reusable widget and renders its optional presentation state.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/status_badge_bloc.dart';
import '../bloc/status_badge_state.dart';

/// Builds a reusable widget and renders its optional presentation state.
class StatusBadgeWidget extends StatelessWidget {
  const StatusBadgeWidget({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<StatusBadgeBloc>();
    return BlocBuilder<StatusBadgeBloc, StatusBadgeState>(
      builder: (context, state) => switch (state) {
        StatusBadgeInitial() => const SizedBox.shrink(),
        StatusBadgeUpdated(:final value) => Text('$value'),
      },
    );
  }
}
