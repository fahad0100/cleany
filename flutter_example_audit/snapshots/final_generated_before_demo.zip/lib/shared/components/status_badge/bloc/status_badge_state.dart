// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part 'status_badge_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class StatusBadgeState with _$StatusBadgeState {
  const factory StatusBadgeState.initial() = StatusBadgeInitial;
  const factory StatusBadgeState.updated(int value) = StatusBadgeUpdated;
}
