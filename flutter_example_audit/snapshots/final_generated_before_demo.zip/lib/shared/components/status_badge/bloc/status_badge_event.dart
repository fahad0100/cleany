// Defines the events that trigger operations in the generated Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part 'status_badge_event.freezed.dart';

/// Defines the events that trigger operations in the generated Bloc.
@freezed
sealed class StatusBadgeEvent with _$StatusBadgeEvent {
  const factory StatusBadgeEvent.requested() = StatusBadgeRequested;
}
