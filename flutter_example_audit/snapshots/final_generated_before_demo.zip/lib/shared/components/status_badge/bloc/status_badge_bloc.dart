// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';

import 'status_badge_state.dart';
import 'status_badge_event.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class StatusBadgeBloc extends Bloc<StatusBadgeEvent, StatusBadgeState> {
  StatusBadgeBloc() : super(const StatusBadgeState.initial()) {
    on<StatusBadgeRequested>(_onRequested);
  }
  // Component actions after disposal are ignored, matching Cubit.update.
  @override
  void add(StatusBadgeEvent event) {
    if (!isClosed) super.add(event);
  }

  Future<void> _onRequested(
    StatusBadgeRequested event,
    Emitter<StatusBadgeState> emit,
  ) async {
    if (!emit.isDone) emit(const StatusBadgeState.updated(1));
  }
}
