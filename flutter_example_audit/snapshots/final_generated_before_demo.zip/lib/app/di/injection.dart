// Registers application-scoped services and factory presentation controllers.
import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';

import '../config/app_config.dart';
import '../../core/network/dio/dio_client.dart';

import 'package:test_cleany_project/features/home/data/datasources/home_remote_data_source.dart';
import 'package:test_cleany_project/features/home/data/repositories/home_repository_impl.dart';
import 'package:test_cleany_project/features/home/domain/repositories/home_repository.dart';
import 'package:test_cleany_project/features/home/domain/usecases/get_home.dart';
import 'package:test_cleany_project/core/network/retrofit/home_api.dart';
import 'package:test_cleany_project/features/home/presentation/cubit/home_cubit.dart';
import 'package:test_cleany_project/modules/shop/catalog/data/datasources/catalog_remote_data_source.dart';
import 'package:test_cleany_project/modules/shop/catalog/data/repositories/catalog_repository_impl.dart';
import 'package:test_cleany_project/modules/shop/catalog/domain/repositories/catalog_repository.dart';
import 'package:test_cleany_project/modules/shop/catalog/domain/usecases/get_catalog.dart';
import 'package:test_cleany_project/core/network/retrofit/catalog_api.dart';
import 'package:test_cleany_project/modules/shop/catalog/presentation/bloc/catalog_bloc.dart';
import 'package:test_cleany_project/components/user_card/cubit/user_card_cubit.dart';
import 'package:test_cleany_project/shared/components/status_badge/bloc/status_badge_bloc.dart';
import 'package:test_cleany_project/features/typed_fields/data/datasources/typed_fields_remote_data_source.dart';
import 'package:test_cleany_project/features/typed_fields/data/repositories/typed_fields_repository_impl.dart';
import 'package:test_cleany_project/features/typed_fields/domain/repositories/typed_fields_repository.dart';
import 'package:test_cleany_project/features/typed_fields/domain/usecases/get_typed_fields.dart';
import 'package:test_cleany_project/core/network/retrofit/typed_fields_api.dart';
import 'package:test_cleany_project/features/typed_fields/presentation/bloc/typed_fields_bloc.dart';

// One composition root. Application services live in an explicit app scope.
// Repositories are lazy singletons; presentation controllers are factories.
/// Registers application-scoped services and factory presentation controllers.
Future<void> configureDependencies(GetIt container, AppConfig config) async {
  container.pushNewScope(scopeName: 'app');
  try {
    container.registerSingleton<AppConfig>(config);
    container.registerLazySingleton<Dio>(
      () => createDio(config.apiBaseUrl),
      dispose: (dio) => dio.close(force: true),
    );
    registerFeatureDependencies(container);
  } catch (_) {
    await container.popScope();
    rethrow;
  }
}

/// Registers application-scoped services and factory presentation controllers.
void registerFeatureDependencies(GetIt container) {
  container.registerLazySingleton<HomeApi>(() => HomeApi(container<Dio>()));
  container.registerLazySingleton<HomeRemoteDataSource>(
    () => HomeRemoteDataSource(container<HomeApi>()),
  );
  container.registerLazySingleton<HomeRepository>(
    () => HomeRepositoryImpl(container<HomeRemoteDataSource>()),
  );
  container.registerLazySingleton<GetHome>(
    () => GetHome(container<HomeRepository>()),
  );

  container.registerFactory<HomeCubit>(() => HomeCubit(container<GetHome>()));

  container.registerLazySingleton<CatalogApi>(
    () => CatalogApi(container<Dio>()),
  );
  container.registerLazySingleton<CatalogRemoteDataSource>(
    () => CatalogRemoteDataSource(container<CatalogApi>()),
  );
  container.registerLazySingleton<CatalogRepository>(
    () => CatalogRepositoryImpl(container<CatalogRemoteDataSource>()),
  );
  container.registerLazySingleton<GetCatalog>(
    () => GetCatalog(container<CatalogRepository>()),
  );

  container.registerFactory<CatalogBloc>(
    () => CatalogBloc(container<GetCatalog>()),
  );

  container.registerFactory<UserCardCubit>(() => UserCardCubit());

  container.registerFactory<StatusBadgeBloc>(() => StatusBadgeBloc());

  container.registerLazySingleton<TypedFieldsApi>(
    () => TypedFieldsApi(container<Dio>()),
  );
  container.registerLazySingleton<TypedFieldsRemoteDataSource>(
    () => TypedFieldsRemoteDataSource(container<TypedFieldsApi>()),
  );
  container.registerLazySingleton<TypedFieldsRepository>(
    () => TypedFieldsRepositoryImpl(container<TypedFieldsRemoteDataSource>()),
  );
  container.registerLazySingleton<GetTypedFields>(
    () => GetTypedFields(container<TypedFieldsRepository>()),
  );

  container.registerFactory<TypedFieldsBloc>(
    () => TypedFieldsBloc(container<GetTypedFields>()),
  );
}

/// Registers application-scoped services and factory presentation controllers.
Future<void> disposeDependencies(GetIt container) => container.popScope();
