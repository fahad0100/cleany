// Defines navigation paths and connects routes to presentation factories.
/// Defines navigation paths and connects routes to presentation factories.
class RouteNames {
  RouteNames._();
  static const root = '/';

  static const home = '/home';

  static const catalog = '/catalog';

  static const typedFields = '/typed_fields';
}
