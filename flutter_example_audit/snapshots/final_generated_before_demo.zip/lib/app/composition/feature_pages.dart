// Creates presentation widgets and owns their Cubit/Bloc providers.
// Presentation factories are wired here, keeping the router independent of
// controllers and data-layer implementation details.
import 'package:flutter/widgets.dart';
import 'package:get_it/get_it.dart';

import '../../core/localization/generated/app_localizations.dart';

import 'package:test_cleany_project/features/home/presentation/pages/home_page.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_cleany_project/features/home/presentation/cubit/home_cubit.dart';
import 'package:test_cleany_project/modules/shop/catalog/presentation/pages/catalog_page.dart';
import 'package:test_cleany_project/modules/shop/catalog/presentation/bloc/catalog_bloc.dart';
import 'package:test_cleany_project/modules/shop/catalog/presentation/bloc/catalog_event.dart';
import 'package:test_cleany_project/components/user_card/widgets/user_card_widget.dart';
import 'package:test_cleany_project/components/user_card/cubit/user_card_cubit.dart';
import 'package:test_cleany_project/shared/components/status_badge/widgets/status_badge_widget.dart';
import 'package:test_cleany_project/shared/components/status_badge/bloc/status_badge_bloc.dart';
import 'package:test_cleany_project/features/home/subfeatures/empty_state/widgets/empty_state_widget.dart';
import 'package:test_cleany_project/features/typed_fields/presentation/pages/typed_fields_page.dart';
import 'package:test_cleany_project/features/typed_fields/presentation/bloc/typed_fields_bloc.dart';
import 'package:test_cleany_project/features/typed_fields/presentation/bloc/typed_fields_event.dart';

/// Creates presentation widgets and owns their Cubit/Bloc providers.
class FeaturePages {
  FeaturePages._();
  static Widget placeholder(GetIt container) => Builder(
    builder: (context) =>
        Center(child: Text(AppLocalizations.of(context).welcome)),
  );

  static Widget home(GetIt container) => BlocProvider<HomeCubit>(
    create: (_) => container<HomeCubit>()..load(),
    child: const HomePage(),
  );

  static Widget catalog(GetIt container) => BlocProvider<CatalogBloc>(
    create: (_) =>
        container<CatalogBloc>()..add(const CatalogEvent.requested()),
    child: const CatalogPage(),
  );

  static Widget userCard(GetIt container) => BlocProvider<UserCardCubit>(
    create: (_) => container<UserCardCubit>(),
    child: const UserCardWidget(),
  );

  static Widget statusBadge(GetIt container) => BlocProvider<StatusBadgeBloc>(
    create: (_) => container<StatusBadgeBloc>(),
    child: const StatusBadgeWidget(),
  );

  static Widget emptyState(GetIt container) => const EmptyStateWidget();

  static Widget typedFields(GetIt container) => BlocProvider<TypedFieldsBloc>(
    create: (_) =>
        container<TypedFieldsBloc>()..add(const TypedFieldsEvent.requested()),
    child: const TypedFieldsPage(),
  );
}
