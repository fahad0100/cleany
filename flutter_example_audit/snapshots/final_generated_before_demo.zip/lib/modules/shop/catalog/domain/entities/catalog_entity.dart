// Defines immutable business data consumed by use cases and presentation.
import 'package:freezed_annotation/freezed_annotation.dart';
part 'catalog_entity.freezed.dart';

/// Defines immutable business data consumed by use cases and presentation.
@freezed
abstract class CatalogEntity with _$CatalogEntity {
  const factory CatalogEntity({required String id}) = _CatalogEntity;
}
