// Exposes one business operation through the domain repository contract.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';

import '../entities/catalog_entity.dart';
import '../repositories/catalog_repository.dart';

/// Exposes one business operation through the domain repository contract.
class GetCatalog {
  const GetCatalog(this._repository);
  final CatalogRepository _repository;
  Future<Result<CatalogEntity, Failure>> call() => _repository.fetch();
}
