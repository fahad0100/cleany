// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'catalog_entity.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$CatalogEntity {

 String get id;
/// Create a copy of CatalogEntity
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$CatalogEntityCopyWith<CatalogEntity> get copyWith => _$CatalogEntityCopyWithImpl<CatalogEntity>(this as CatalogEntity, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as CatalogEntity;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is CatalogEntity&&(identical(other.id, _this.id) || other.id == _this.id));
}


@override
int get hashCode {
  final _this = this as CatalogEntity;
  return Object.hash(runtimeType,_this.id);
}

@override
String toString() {
  final _this = this as CatalogEntity;
  return 'CatalogEntity(id: ${_this.id})';
}


}

/// @nodoc
abstract mixin class $CatalogEntityCopyWith<$Res>  {
  factory $CatalogEntityCopyWith(CatalogEntity value, $Res Function(CatalogEntity) _then) = _$CatalogEntityCopyWithImpl;
@useResult
$Res call({
 String id
});




}
/// @nodoc
class _$CatalogEntityCopyWithImpl<$Res>
    implements $CatalogEntityCopyWith<$Res> {
  _$CatalogEntityCopyWithImpl(this._self, this._then);

  final CatalogEntity _self;
  final $Res Function(CatalogEntity) _then;

/// Create a copy of CatalogEntity
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,}) {
  return _then(CatalogEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,
  ));
}

}


/// Adds pattern-matching-related methods to [CatalogEntity].
extension CatalogEntityPatterns on CatalogEntity {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _CatalogEntity value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _CatalogEntity() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _CatalogEntity value)  $default,){
final _that = this;
switch (_that) {
case _CatalogEntity():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _CatalogEntity value)?  $default,){
final _that = this;
switch (_that) {
case _CatalogEntity() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _CatalogEntity() when $default != null:
return $default(_that.id);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id)  $default,) {final _that = this;
switch (_that) {
case _CatalogEntity():
return $default(_that.id);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id)?  $default,) {final _that = this;
switch (_that) {
case _CatalogEntity() when $default != null:
return $default(_that.id);case _:
  return null;

}
}

}

/// @nodoc


class _CatalogEntity implements CatalogEntity {
  const _CatalogEntity({required this.id});
  

@override final  String id;

/// Create a copy of CatalogEntity
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$CatalogEntityCopyWith<_CatalogEntity> get copyWith => __$CatalogEntityCopyWithImpl<_CatalogEntity>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _CatalogEntity&&(identical(other.id, id) || other.id == id));
}


@override
int get hashCode {
    return Object.hash(runtimeType,id);
}

@override
String toString() {
    return 'CatalogEntity(id: $id)';
}


}

/// @nodoc
abstract mixin class _$CatalogEntityCopyWith<$Res> implements $CatalogEntityCopyWith<$Res> {
  factory _$CatalogEntityCopyWith(_CatalogEntity value, $Res Function(_CatalogEntity) _then) = __$CatalogEntityCopyWithImpl;
@override @useResult
$Res call({
 String id
});




}
/// @nodoc
class __$CatalogEntityCopyWithImpl<$Res>
    implements _$CatalogEntityCopyWith<$Res> {
  __$CatalogEntityCopyWithImpl(this._self, this._then);

  final _CatalogEntity _self;
  final $Res Function(_CatalogEntity) _then;

/// Create a copy of CatalogEntity
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,}) {
  return _then(_CatalogEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
