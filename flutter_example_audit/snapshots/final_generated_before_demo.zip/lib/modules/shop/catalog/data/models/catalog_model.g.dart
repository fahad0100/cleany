// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'catalog_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_CatalogModel _$CatalogModelFromJson(Map<String, dynamic> json) =>
    _CatalogModel(id: json['id'] as String);

Map<String, dynamic> _$CatalogModelToJson(_CatalogModel instance) =>
    <String, dynamic>{'id': instance.id};
