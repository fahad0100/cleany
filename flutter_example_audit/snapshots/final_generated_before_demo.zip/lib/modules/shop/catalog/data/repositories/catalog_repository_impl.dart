// Converts JSON/models into entities and returns Success or Failure exactly once.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
import 'package:test_cleany_project/core/errors/error_reporter.dart';
import 'package:test_cleany_project/core/network/failure_mapper.dart';
import 'package:test_cleany_project/modules/shop/catalog/domain/entities/catalog_entity.dart';
import 'package:test_cleany_project/modules/shop/catalog/domain/repositories/catalog_repository.dart';

import '../datasources/catalog_remote_data_source.dart';
import '../models/catalog_model.dart';

/// Converts JSON/models into entities and returns Success or Failure exactly once.
class CatalogRepositoryImpl implements CatalogRepository {
  const CatalogRepositoryImpl(
    this._remote, {
    this.reportError = reportUnexpectedError,
  });
  final CatalogRemoteDataSource _remote;
  final ErrorReporter reportError;
  @override
  Future<Result<CatalogEntity, Failure>> fetch() async {
    try {
      final json = await _remote.fetch();
      final model = CatalogModel.fromJson(json);
      return Success(CatalogEntity(id: model.id));
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) reportError(error, stackTrace);
      return Error(failure);
    }
  }
}
