// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_cleany_project/modules/shop/catalog/domain/usecases/get_catalog.dart';

import 'catalog_state.dart';
import 'catalog_event.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class CatalogBloc extends Bloc<CatalogEvent, CatalogState> {
  final GetCatalog _getCatalog;
  CatalogBloc(this._getCatalog) : super(const CatalogState.initial()) {
    on<CatalogRequested>(_onRequested);
  }

  Future<void> _onRequested(
    CatalogRequested event,
    Emitter<CatalogState> emit,
  ) async {
    if (state is CatalogLoading) return;
    emit(const CatalogState.loading());
    final result = await _getCatalog();
    if (emit.isDone) return;
    result.when(
      (entity) => emit(CatalogState.success(entity)),
      (failure) => emit(CatalogState.failure(failure)),
    );
  }
}
