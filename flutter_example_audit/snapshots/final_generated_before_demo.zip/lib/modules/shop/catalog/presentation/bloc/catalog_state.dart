// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:test_cleany_project/modules/shop/catalog/domain/entities/catalog_entity.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
part 'catalog_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class CatalogState with _$CatalogState {
  const factory CatalogState.initial() = CatalogInitial;
  const factory CatalogState.loading() = CatalogLoading;
  const factory CatalogState.success(CatalogEntity entity) = CatalogSuccess;
  const factory CatalogState.failure(Failure failure) = CatalogFailure;
}
