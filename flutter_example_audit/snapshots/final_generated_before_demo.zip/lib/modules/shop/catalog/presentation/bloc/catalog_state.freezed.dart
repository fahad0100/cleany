// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'catalog_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$CatalogState {





@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is CatalogState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'CatalogState()';
}


}

/// @nodoc
class $CatalogStateCopyWith<$Res>  {
$CatalogStateCopyWith(CatalogState _, $Res Function(CatalogState) __);
}


/// Adds pattern-matching-related methods to [CatalogState].
extension CatalogStatePatterns on CatalogState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( CatalogInitial value)?  initial,TResult Function( CatalogLoading value)?  loading,TResult Function( CatalogSuccess value)?  success,TResult Function( CatalogFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case CatalogInitial() when initial != null:
return initial(_that);case CatalogLoading() when loading != null:
return loading(_that);case CatalogSuccess() when success != null:
return success(_that);case CatalogFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( CatalogInitial value)  initial,required TResult Function( CatalogLoading value)  loading,required TResult Function( CatalogSuccess value)  success,required TResult Function( CatalogFailure value)  failure,}){
final _that = this;
switch (_that) {
case CatalogInitial():
return initial(_that);case CatalogLoading():
return loading(_that);case CatalogSuccess():
return success(_that);case CatalogFailure():
return failure(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( CatalogInitial value)?  initial,TResult? Function( CatalogLoading value)?  loading,TResult? Function( CatalogSuccess value)?  success,TResult? Function( CatalogFailure value)?  failure,}){
final _that = this;
switch (_that) {
case CatalogInitial() when initial != null:
return initial(_that);case CatalogLoading() when loading != null:
return loading(_that);case CatalogSuccess() when success != null:
return success(_that);case CatalogFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( CatalogEntity entity)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case CatalogInitial() when initial != null:
return initial();case CatalogLoading() when loading != null:
return loading();case CatalogSuccess() when success != null:
return success(_that.entity);case CatalogFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( CatalogEntity entity)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case CatalogInitial():
return initial();case CatalogLoading():
return loading();case CatalogSuccess():
return success(_that.entity);case CatalogFailure():
return failure(_that.failure);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( CatalogEntity entity)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case CatalogInitial() when initial != null:
return initial();case CatalogLoading() when loading != null:
return loading();case CatalogSuccess() when success != null:
return success(_that.entity);case CatalogFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class CatalogInitial implements CatalogState {
  const CatalogInitial();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is CatalogInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'CatalogState.initial()';
}


}




/// @nodoc


class CatalogLoading implements CatalogState {
  const CatalogLoading();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is CatalogLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'CatalogState.loading()';
}


}




/// @nodoc


class CatalogSuccess implements CatalogState {
  const CatalogSuccess(this.entity);
  

 final  CatalogEntity entity;

/// Create a copy of CatalogState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$CatalogSuccessCopyWith<CatalogSuccess> get copyWith => _$CatalogSuccessCopyWithImpl<CatalogSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is CatalogSuccess&&(identical(other.entity, entity) || other.entity == entity));
}


@override
int get hashCode {
    return Object.hash(runtimeType,entity);
}

@override
String toString() {
    return 'CatalogState.success(entity: $entity)';
}


}

/// @nodoc
abstract mixin class $CatalogSuccessCopyWith<$Res> implements $CatalogStateCopyWith<$Res> {
  factory $CatalogSuccessCopyWith(CatalogSuccess value, $Res Function(CatalogSuccess) _then) = _$CatalogSuccessCopyWithImpl;
@useResult
$Res call({
 CatalogEntity entity
});


$CatalogEntityCopyWith<$Res> get entity;

}
/// @nodoc
class _$CatalogSuccessCopyWithImpl<$Res>
    implements $CatalogSuccessCopyWith<$Res> {
  _$CatalogSuccessCopyWithImpl(this._self, this._then);

  final CatalogSuccess _self;
  final $Res Function(CatalogSuccess) _then;

/// Create a copy of CatalogState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? entity = null,}) {
  return _then(CatalogSuccess(
null == entity ? _self.entity : entity // ignore: cast_nullable_to_non_nullable
as CatalogEntity,
  ));
}

/// Create a copy of CatalogState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$CatalogEntityCopyWith<$Res> get entity {
  
  return $CatalogEntityCopyWith<$Res>(_self.entity, (value) {
    return _then(_self.copyWith(entity: value));
  });
}
}

/// @nodoc


class CatalogFailure implements CatalogState {
  const CatalogFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of CatalogState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$CatalogFailureCopyWith<CatalogFailure> get copyWith => _$CatalogFailureCopyWithImpl<CatalogFailure>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is CatalogFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode {
    return Object.hash(runtimeType,failure);
}

@override
String toString() {
    return 'CatalogState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $CatalogFailureCopyWith<$Res> implements $CatalogStateCopyWith<$Res> {
  factory $CatalogFailureCopyWith(CatalogFailure value, $Res Function(CatalogFailure) _then) = _$CatalogFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});




}
/// @nodoc
class _$CatalogFailureCopyWithImpl<$Res>
    implements $CatalogFailureCopyWith<$Res> {
  _$CatalogFailureCopyWithImpl(this._self, this._then);

  final CatalogFailure _self;
  final $Res Function(CatalogFailure) _then;

/// Create a copy of CatalogState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(CatalogFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}


}

// dart format on
