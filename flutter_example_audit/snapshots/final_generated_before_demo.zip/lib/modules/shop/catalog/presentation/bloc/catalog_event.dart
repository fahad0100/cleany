// Defines the events that trigger operations in the generated Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part 'catalog_event.freezed.dart';

/// Defines the events that trigger operations in the generated Bloc.
@freezed
sealed class CatalogEvent with _$CatalogEvent {
  const factory CatalogEvent.requested() = CatalogRequested;
}
