// Builds the feature page and renders loading, entity success, and failure states.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/catalog_bloc.dart';
import '../bloc/catalog_state.dart';

/// Builds the feature page and renders loading, entity success, and failure states.
class CatalogPage extends StatelessWidget {
  const CatalogPage({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<CatalogBloc>();
    return Scaffold(
      appBar: AppBar(title: const Text('Catalog')),
      body: BlocBuilder<CatalogBloc, CatalogState>(
        builder: (context, state) => switch (state) {
          CatalogInitial() => const SizedBox.shrink(),
          CatalogLoading() => const Center(child: CircularProgressIndicator()),
          CatalogSuccess(:final entity) => Center(
            child: Text(entity.id.toString()),
          ),
          CatalogFailure(:final failure) => Center(
            child: Text(failure.message),
          ),
        },
      ),
    );
  }
}
