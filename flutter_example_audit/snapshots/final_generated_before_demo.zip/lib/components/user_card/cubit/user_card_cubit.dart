// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';

import 'user_card_state.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class UserCardCubit extends Cubit<UserCardState> {
  UserCardCubit() : super(const UserCardState.initial());

  void update(int value) {
    if (!isClosed) emit(UserCardState.updated(value));
  }
}
