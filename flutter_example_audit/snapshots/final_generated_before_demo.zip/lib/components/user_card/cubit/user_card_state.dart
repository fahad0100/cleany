// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_card_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class UserCardState with _$UserCardState {
  const factory UserCardState.initial() = UserCardInitial;
  const factory UserCardState.updated(int value) = UserCardUpdated;
}
