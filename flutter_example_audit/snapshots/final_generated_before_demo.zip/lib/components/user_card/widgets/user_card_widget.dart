// Builds a reusable widget and renders its optional presentation state.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubit/user_card_cubit.dart';
import '../cubit/user_card_state.dart';

/// Builds a reusable widget and renders its optional presentation state.
class UserCardWidget extends StatelessWidget {
  const UserCardWidget({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<UserCardCubit>();
    return BlocBuilder<UserCardCubit, UserCardState>(
      builder: (context, state) => switch (state) {
        UserCardInitial() => const SizedBox.shrink(),
        UserCardUpdated(:final value) => Text('$value'),
      },
    );
  }
}
