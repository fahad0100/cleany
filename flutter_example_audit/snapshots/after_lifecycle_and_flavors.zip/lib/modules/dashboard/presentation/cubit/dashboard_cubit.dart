// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';
import "package:test_cleany_project/modules/dashboard/domain/usecases/get_dashboard.dart";

import "dashboard_state.dart";

/// Runs presentation actions and emits the corresponding immutable states.
class DashboardCubit extends Cubit<DashboardState> {
  final GetDashboard _getDashboard;
  DashboardCubit(this._getDashboard) : super(const DashboardState.initial());

  Future<void> load() async {
    if (isClosed || state is DashboardLoading) return;
    emit(const DashboardState.loading());
    final result = await _getDashboard();
    if (isClosed) return;
    result.when(
      (entity) => emit(DashboardState.success(entity)),
      (failure) => emit(DashboardState.failure(failure)),
    );
  }
}
