// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';
import "package:test_cleany_project/modules/dashboard/domain/entities/dashboard_entity.dart";
import 'package:test_cleany_project/core/errors/failure.dart';
part "dashboard_state.freezed.dart";

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class DashboardState with _$DashboardState {
  const factory DashboardState.initial() = DashboardInitial;
  const factory DashboardState.loading() = DashboardLoading;
  const factory DashboardState.success(DashboardEntity entity) = DashboardSuccess;
  const factory DashboardState.failure(Failure failure) = DashboardFailure;
}
