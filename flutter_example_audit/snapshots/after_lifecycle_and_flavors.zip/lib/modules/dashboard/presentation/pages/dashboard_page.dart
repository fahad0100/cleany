// Builds the feature page and renders loading, entity success, and failure states.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import "../cubit/dashboard_cubit.dart";
import "../cubit/dashboard_state.dart";

/// Builds the feature page and renders loading, entity success, and failure states.
class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<DashboardCubit>();
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: BlocBuilder<DashboardCubit, DashboardState>(
        builder: (context, state) => switch (state) {
          DashboardInitial() => const SizedBox.shrink(),
          DashboardLoading() => const Center(child: CircularProgressIndicator()),
          DashboardSuccess(:final entity) => Center(
            child: Text(entity.id.toString()),
          ),
          DashboardFailure(:final failure) => Center(child: Text(failure.message)),
        },
      ),
    );
  }
}
