// Defines immutable business data consumed by use cases and presentation.
import 'package:freezed_annotation/freezed_annotation.dart';
part 'details_entity.freezed.dart';

/// Defines immutable business data consumed by use cases and presentation.
@freezed
abstract class DetailsEntity with _$DetailsEntity {
  const factory DetailsEntity({required String id}) = _DetailsEntity;
}
