// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';
import "package:test_cleany_project/modules/dashboard/subfeatures/details/domain/usecases/get_details.dart";

import 'details_state.dart';

/// Runs presentation actions and emits the corresponding immutable states.
class DetailsCubit extends Cubit<DetailsState> {
  final GetDetails _getDetails;
  DetailsCubit(this._getDetails) : super(const DetailsState.initial());

  Future<void> load() async {
    if (isClosed || state is DetailsLoading) return;
    emit(const DetailsState.loading());
    final result = await _getDetails();
    if (isClosed) return;
    result.when(
      (entity) => emit(DetailsState.success(entity)),
      (failure) => emit(DetailsState.failure(failure)),
    );
  }
}
