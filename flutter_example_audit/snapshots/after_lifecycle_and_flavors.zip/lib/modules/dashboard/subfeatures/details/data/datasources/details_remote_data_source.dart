// Fetches raw JSON and propagates exceptions to the repository.
import 'package:test_cleany_project/core/network/retrofit/details_api.dart';

/// Fetches raw JSON and propagates exceptions to the repository.
class DetailsRemoteDataSource {
  const DetailsRemoteDataSource(this._api);
  final DetailsApi _api;
  // Raw JSON only. Conversion and Failure mapping belong to the repository.
  Future<Map<String, dynamic>> fetch() => _api.fetch();
}
