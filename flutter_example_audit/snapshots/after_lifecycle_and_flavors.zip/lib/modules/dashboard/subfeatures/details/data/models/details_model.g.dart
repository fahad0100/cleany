// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'details_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_DetailsModel _$DetailsModelFromJson(Map<String, dynamic> json) =>
    _DetailsModel(id: json['id'] as String);

Map<String, dynamic> _$DetailsModelToJson(_DetailsModel instance) =>
    <String, dynamic>{'id': instance.id};
