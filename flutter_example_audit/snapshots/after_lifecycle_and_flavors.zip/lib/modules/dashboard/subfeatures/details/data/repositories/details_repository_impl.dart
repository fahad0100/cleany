// Converts JSON/models into entities and returns Success or Failure exactly once.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
import 'package:test_cleany_project/core/errors/error_reporter.dart';
import 'package:test_cleany_project/core/network/failure_mapper.dart';
import "package:test_cleany_project/modules/dashboard/subfeatures/details/domain/entities/details_entity.dart";
import "package:test_cleany_project/modules/dashboard/subfeatures/details/domain/repositories/details_repository.dart";

import '../datasources/details_remote_data_source.dart';
import '../models/details_model.dart';

/// Converts JSON/models into entities and returns Success or Failure exactly once.
class DetailsRepositoryImpl implements DetailsRepository {
  const DetailsRepositoryImpl(
    this._remote, {
    this.reportError = reportUnexpectedError,
  });
  final DetailsRemoteDataSource _remote;
  final ErrorReporter reportError;
  @override
  Future<Result<DetailsEntity, Failure>> fetch() async {
    try {
      final json = await _remote.fetch();
      final model = DetailsModel.fromJson(json);
      return Success(DetailsEntity(id: model.id));
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) reportError(error, stackTrace);
      return Error(failure);
    }
  }
}
