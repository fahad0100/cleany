// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'details_entity.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$DetailsEntity {

 String get id;
/// Create a copy of DetailsEntity
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$DetailsEntityCopyWith<DetailsEntity> get copyWith => _$DetailsEntityCopyWithImpl<DetailsEntity>(this as DetailsEntity, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as DetailsEntity;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is DetailsEntity&&(identical(other.id, _this.id) || other.id == _this.id));
}


@override
int get hashCode {
  final _this = this as DetailsEntity;
  return Object.hash(runtimeType,_this.id);
}

@override
String toString() {
  final _this = this as DetailsEntity;
  return 'DetailsEntity(id: ${_this.id})';
}


}

/// @nodoc
abstract mixin class $DetailsEntityCopyWith<$Res>  {
  factory $DetailsEntityCopyWith(DetailsEntity value, $Res Function(DetailsEntity) _then) = _$DetailsEntityCopyWithImpl;
@useResult
$Res call({
 String id
});




}
/// @nodoc
class _$DetailsEntityCopyWithImpl<$Res>
    implements $DetailsEntityCopyWith<$Res> {
  _$DetailsEntityCopyWithImpl(this._self, this._then);

  final DetailsEntity _self;
  final $Res Function(DetailsEntity) _then;

/// Create a copy of DetailsEntity
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,}) {
  return _then(DetailsEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,
  ));
}

}


/// Adds pattern-matching-related methods to [DetailsEntity].
extension DetailsEntityPatterns on DetailsEntity {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _DetailsEntity value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _DetailsEntity() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _DetailsEntity value)  $default,){
final _that = this;
switch (_that) {
case _DetailsEntity():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _DetailsEntity value)?  $default,){
final _that = this;
switch (_that) {
case _DetailsEntity() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _DetailsEntity() when $default != null:
return $default(_that.id);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id)  $default,) {final _that = this;
switch (_that) {
case _DetailsEntity():
return $default(_that.id);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id)?  $default,) {final _that = this;
switch (_that) {
case _DetailsEntity() when $default != null:
return $default(_that.id);case _:
  return null;

}
}

}

/// @nodoc


class _DetailsEntity implements DetailsEntity {
  const _DetailsEntity({required this.id});
  

@override final  String id;

/// Create a copy of DetailsEntity
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$DetailsEntityCopyWith<_DetailsEntity> get copyWith => __$DetailsEntityCopyWithImpl<_DetailsEntity>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _DetailsEntity&&(identical(other.id, id) || other.id == id));
}


@override
int get hashCode {
    return Object.hash(runtimeType,id);
}

@override
String toString() {
    return 'DetailsEntity(id: $id)';
}


}

/// @nodoc
abstract mixin class _$DetailsEntityCopyWith<$Res> implements $DetailsEntityCopyWith<$Res> {
  factory _$DetailsEntityCopyWith(_DetailsEntity value, $Res Function(_DetailsEntity) _then) = __$DetailsEntityCopyWithImpl;
@override @useResult
$Res call({
 String id
});




}
/// @nodoc
class __$DetailsEntityCopyWithImpl<$Res>
    implements _$DetailsEntityCopyWith<$Res> {
  __$DetailsEntityCopyWithImpl(this._self, this._then);

  final _DetailsEntity _self;
  final $Res Function(_DetailsEntity) _then;

/// Create a copy of DetailsEntity
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,}) {
  return _then(_DetailsEntity(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
