// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';
import "package:test_cleany_project/modules/dashboard/subfeatures/details/domain/entities/details_entity.dart";
import 'package:test_cleany_project/core/errors/failure.dart';
part 'details_state.freezed.dart';

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class DetailsState with _$DetailsState {
  const factory DetailsState.initial() = DetailsInitial;
  const factory DetailsState.loading() = DetailsLoading;
  const factory DetailsState.success(DetailsEntity entity) = DetailsSuccess;
  const factory DetailsState.failure(Failure failure) = DetailsFailure;
}
