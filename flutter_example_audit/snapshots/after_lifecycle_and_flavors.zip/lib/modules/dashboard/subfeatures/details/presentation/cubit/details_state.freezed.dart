// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'details_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$DetailsState {





@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is DetailsState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'DetailsState()';
}


}

/// @nodoc
class $DetailsStateCopyWith<$Res>  {
$DetailsStateCopyWith(DetailsState _, $Res Function(DetailsState) __);
}


/// Adds pattern-matching-related methods to [DetailsState].
extension DetailsStatePatterns on DetailsState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( DetailsInitial value)?  initial,TResult Function( DetailsLoading value)?  loading,TResult Function( DetailsSuccess value)?  success,TResult Function( DetailsFailure value)?  failure,required TResult orElse(),}){
final _that = this;
switch (_that) {
case DetailsInitial() when initial != null:
return initial(_that);case DetailsLoading() when loading != null:
return loading(_that);case DetailsSuccess() when success != null:
return success(_that);case DetailsFailure() when failure != null:
return failure(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( DetailsInitial value)  initial,required TResult Function( DetailsLoading value)  loading,required TResult Function( DetailsSuccess value)  success,required TResult Function( DetailsFailure value)  failure,}){
final _that = this;
switch (_that) {
case DetailsInitial():
return initial(_that);case DetailsLoading():
return loading(_that);case DetailsSuccess():
return success(_that);case DetailsFailure():
return failure(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( DetailsInitial value)?  initial,TResult? Function( DetailsLoading value)?  loading,TResult? Function( DetailsSuccess value)?  success,TResult? Function( DetailsFailure value)?  failure,}){
final _that = this;
switch (_that) {
case DetailsInitial() when initial != null:
return initial(_that);case DetailsLoading() when loading != null:
return loading(_that);case DetailsSuccess() when success != null:
return success(_that);case DetailsFailure() when failure != null:
return failure(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function()?  loading,TResult Function( DetailsEntity entity)?  success,TResult Function( Failure failure)?  failure,required TResult orElse(),}) {final _that = this;
switch (_that) {
case DetailsInitial() when initial != null:
return initial();case DetailsLoading() when loading != null:
return loading();case DetailsSuccess() when success != null:
return success(_that.entity);case DetailsFailure() when failure != null:
return failure(_that.failure);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function()  loading,required TResult Function( DetailsEntity entity)  success,required TResult Function( Failure failure)  failure,}) {final _that = this;
switch (_that) {
case DetailsInitial():
return initial();case DetailsLoading():
return loading();case DetailsSuccess():
return success(_that.entity);case DetailsFailure():
return failure(_that.failure);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function()?  loading,TResult? Function( DetailsEntity entity)?  success,TResult? Function( Failure failure)?  failure,}) {final _that = this;
switch (_that) {
case DetailsInitial() when initial != null:
return initial();case DetailsLoading() when loading != null:
return loading();case DetailsSuccess() when success != null:
return success(_that.entity);case DetailsFailure() when failure != null:
return failure(_that.failure);case _:
  return null;

}
}

}

/// @nodoc


class DetailsInitial implements DetailsState {
  const DetailsInitial();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is DetailsInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'DetailsState.initial()';
}


}




/// @nodoc


class DetailsLoading implements DetailsState {
  const DetailsLoading();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is DetailsLoading);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'DetailsState.loading()';
}


}




/// @nodoc


class DetailsSuccess implements DetailsState {
  const DetailsSuccess(this.entity);
  

 final  DetailsEntity entity;

/// Create a copy of DetailsState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$DetailsSuccessCopyWith<DetailsSuccess> get copyWith => _$DetailsSuccessCopyWithImpl<DetailsSuccess>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is DetailsSuccess&&(identical(other.entity, entity) || other.entity == entity));
}


@override
int get hashCode {
    return Object.hash(runtimeType,entity);
}

@override
String toString() {
    return 'DetailsState.success(entity: $entity)';
}


}

/// @nodoc
abstract mixin class $DetailsSuccessCopyWith<$Res> implements $DetailsStateCopyWith<$Res> {
  factory $DetailsSuccessCopyWith(DetailsSuccess value, $Res Function(DetailsSuccess) _then) = _$DetailsSuccessCopyWithImpl;
@useResult
$Res call({
 DetailsEntity entity
});


$DetailsEntityCopyWith<$Res> get entity;

}
/// @nodoc
class _$DetailsSuccessCopyWithImpl<$Res>
    implements $DetailsSuccessCopyWith<$Res> {
  _$DetailsSuccessCopyWithImpl(this._self, this._then);

  final DetailsSuccess _self;
  final $Res Function(DetailsSuccess) _then;

/// Create a copy of DetailsState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? entity = null,}) {
  return _then(DetailsSuccess(
null == entity ? _self.entity : entity // ignore: cast_nullable_to_non_nullable
as DetailsEntity,
  ));
}

/// Create a copy of DetailsState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$DetailsEntityCopyWith<$Res> get entity {
  
  return $DetailsEntityCopyWith<$Res>(_self.entity, (value) {
    return _then(_self.copyWith(entity: value));
  });
}
}

/// @nodoc


class DetailsFailure implements DetailsState {
  const DetailsFailure(this.failure);
  

 final  Failure failure;

/// Create a copy of DetailsState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$DetailsFailureCopyWith<DetailsFailure> get copyWith => _$DetailsFailureCopyWithImpl<DetailsFailure>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is DetailsFailure&&(identical(other.failure, failure) || other.failure == failure));
}


@override
int get hashCode {
    return Object.hash(runtimeType,failure);
}

@override
String toString() {
    return 'DetailsState.failure(failure: $failure)';
}


}

/// @nodoc
abstract mixin class $DetailsFailureCopyWith<$Res> implements $DetailsStateCopyWith<$Res> {
  factory $DetailsFailureCopyWith(DetailsFailure value, $Res Function(DetailsFailure) _then) = _$DetailsFailureCopyWithImpl;
@useResult
$Res call({
 Failure failure
});




}
/// @nodoc
class _$DetailsFailureCopyWithImpl<$Res>
    implements $DetailsFailureCopyWith<$Res> {
  _$DetailsFailureCopyWithImpl(this._self, this._then);

  final DetailsFailure _self;
  final $Res Function(DetailsFailure) _then;

/// Create a copy of DetailsState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? failure = null,}) {
  return _then(DetailsFailure(
null == failure ? _self.failure : failure // ignore: cast_nullable_to_non_nullable
as Failure,
  ));
}


}

// dart format on
