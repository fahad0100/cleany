// Defines the API data model and its generated JSON serialization.
// Freezed forwards JSON annotations to the generated properties.
// ignore_for_file: invalid_annotation_target
import 'package:freezed_annotation/freezed_annotation.dart';
part 'details_model.freezed.dart';
part 'details_model.g.dart';

/// Defines the API data model and its generated JSON serialization.
@freezed
abstract class DetailsModel with _$DetailsModel {
  const factory DetailsModel({required String id}) = _DetailsModel;
  factory DetailsModel.fromJson(Map<String, dynamic> json) =>
      _$DetailsModelFromJson(json);
}
