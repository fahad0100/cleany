// Builds the feature page and renders loading, entity success, and failure states.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubit/details_cubit.dart';
import '../cubit/details_state.dart';

/// Builds the feature page and renders loading, entity success, and failure states.
class DetailsPage extends StatelessWidget {
  const DetailsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<DetailsCubit>();
    return Scaffold(
      appBar: AppBar(title: const Text('Details')),
      body: BlocBuilder<DetailsCubit, DetailsState>(
        builder: (context, state) => switch (state) {
          DetailsInitial() => const SizedBox.shrink(),
          DetailsLoading() => const Center(child: CircularProgressIndicator()),
          DetailsSuccess(:final entity) => Center(
            child: Text(entity.id.toString()),
          ),
          DetailsFailure(:final failure) => Center(
            child: Text(failure.message),
          ),
        },
      ),
    );
  }
}
