// Exposes one business operation through the domain repository contract.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';

import '../entities/details_entity.dart';
import '../repositories/details_repository.dart';

/// Exposes one business operation through the domain repository contract.
class GetDetails {
  const GetDetails(this._repository);
  final DetailsRepository _repository;
  Future<Result<DetailsEntity, Failure>> call() => _repository.fetch();
}
