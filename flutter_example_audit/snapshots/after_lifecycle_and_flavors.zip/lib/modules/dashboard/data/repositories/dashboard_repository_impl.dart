// Converts JSON/models into entities and returns Success or Failure exactly once.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';
import 'package:test_cleany_project/core/errors/error_reporter.dart';
import 'package:test_cleany_project/core/network/failure_mapper.dart';
import "package:test_cleany_project/modules/dashboard/domain/entities/dashboard_entity.dart";
import "package:test_cleany_project/modules/dashboard/domain/repositories/dashboard_repository.dart";

import "../datasources/dashboard_remote_data_source.dart";
import "../models/dashboard_model.dart";

/// Converts JSON/models into entities and returns Success or Failure exactly once.
class DashboardRepositoryImpl implements DashboardRepository {
  const DashboardRepositoryImpl(
    this._remote, {
    this.reportError = reportUnexpectedError,
  });
  final DashboardRemoteDataSource _remote;
  final ErrorReporter reportError;
  @override
  Future<Result<DashboardEntity, Failure>> fetch() async {
    try {
      final json = await _remote.fetch();
      final model = DashboardModel.fromJson(json);
      return Success(
        DashboardEntity(id: model.id, title: model.title, visits: model.visits),
      );
    } catch (error, stackTrace) {
      final failure = mapFailure(error);
      if (failure is UnexpectedFailure) reportError(error, stackTrace);
      return Error(failure);
    }
  }
}
