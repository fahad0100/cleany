// Fetches raw JSON and propagates exceptions to the repository.
import "package:test_cleany_project/core/network/retrofit/dashboard_api.dart";

/// Fetches raw JSON and propagates exceptions to the repository.
class DashboardRemoteDataSource {
  const DashboardRemoteDataSource(this._api);
  final DashboardApi _api;
  // Raw JSON only. Conversion and Failure mapping belong to the repository.
  Future<Map<String, dynamic>> fetch() => _api.fetch();
}
