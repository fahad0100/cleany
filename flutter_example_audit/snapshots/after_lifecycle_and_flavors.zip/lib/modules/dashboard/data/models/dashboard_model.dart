// Defines the API data model and its generated JSON serialization.
// Freezed forwards JSON annotations to the generated properties.
// ignore_for_file: invalid_annotation_target
import 'package:freezed_annotation/freezed_annotation.dart';
part "dashboard_model.freezed.dart";
part "dashboard_model.g.dart";

/// Defines the API data model and its generated JSON serialization.
@freezed
abstract class DashboardModel with _$DashboardModel {
  const factory DashboardModel({
    required String id,
    String? title,
    required int visits,
  }) = _DashboardModel;
  factory DashboardModel.fromJson(Map<String, dynamic> json) =>
      _$DashboardModelFromJson(json);
}
