// Defines immutable business data consumed by use cases and presentation.
import 'package:freezed_annotation/freezed_annotation.dart';
part "dashboard_entity.freezed.dart";

/// Defines immutable business data consumed by use cases and presentation.
@freezed
abstract class DashboardEntity with _$DashboardEntity {
  const factory DashboardEntity({
    required String id,
    String? title,
    required int visits,
  }) = _DashboardEntity;
}
