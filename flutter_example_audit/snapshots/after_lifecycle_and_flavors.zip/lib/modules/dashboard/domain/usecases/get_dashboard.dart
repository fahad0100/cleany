// Exposes one business operation through the domain repository contract.
import 'package:multiple_result/multiple_result.dart';
import 'package:test_cleany_project/core/errors/failure.dart';

import "../entities/dashboard_entity.dart";
import "../repositories/dashboard_repository.dart";

/// Exposes one business operation through the domain repository contract.
class GetDashboard {
  const GetDashboard(this._repository);
  final DashboardRepository _repository;
  Future<Result<DashboardEntity, Failure>> call() => _repository.fetch();
}
