// Builds a reusable widget and renders its optional presentation state.
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import "../cubit/profile_card_cubit.dart";
import "../cubit/profile_card_state.dart";

/// Builds a reusable widget and renders its optional presentation state.
class ProfileCardWidget extends StatelessWidget {
  const ProfileCardWidget({super.key});
  @override
  Widget build(BuildContext context) {
    final _ = context.read<ProfileCardCubit>();
    return BlocBuilder<ProfileCardCubit, ProfileCardState>(
      builder: (context, state) => switch (state) {
        ProfileCardInitial() => const SizedBox.shrink(),
        ProfileCardUpdated(:final value) => Text('$value'),
      },
    );
  }
}
