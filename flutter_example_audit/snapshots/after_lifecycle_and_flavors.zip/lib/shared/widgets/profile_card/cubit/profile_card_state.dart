// Defines immutable presentation states for the generated Cubit or Bloc.
import 'package:freezed_annotation/freezed_annotation.dart';

part "profile_card_state.freezed.dart";

/// Defines immutable presentation states for the generated Cubit or Bloc.
@freezed
sealed class ProfileCardState with _$ProfileCardState {
  const factory ProfileCardState.initial() = ProfileCardInitial;
  const factory ProfileCardState.updated(int value) = ProfileCardUpdated;
}
