// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_card_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$ProfileCardState {





@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ProfileCardState);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'ProfileCardState()';
}


}

/// @nodoc
class $ProfileCardStateCopyWith<$Res>  {
$ProfileCardStateCopyWith(ProfileCardState _, $Res Function(ProfileCardState) __);
}


/// Adds pattern-matching-related methods to [ProfileCardState].
extension ProfileCardStatePatterns on ProfileCardState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>({TResult Function( ProfileCardInitial value)?  initial,TResult Function( ProfileCardUpdated value)?  updated,required TResult orElse(),}){
final _that = this;
switch (_that) {
case ProfileCardInitial() when initial != null:
return initial(_that);case ProfileCardUpdated() when updated != null:
return updated(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>({required TResult Function( ProfileCardInitial value)  initial,required TResult Function( ProfileCardUpdated value)  updated,}){
final _that = this;
switch (_that) {
case ProfileCardInitial():
return initial(_that);case ProfileCardUpdated():
return updated(_that);}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>({TResult? Function( ProfileCardInitial value)?  initial,TResult? Function( ProfileCardUpdated value)?  updated,}){
final _that = this;
switch (_that) {
case ProfileCardInitial() when initial != null:
return initial(_that);case ProfileCardUpdated() when updated != null:
return updated(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>({TResult Function()?  initial,TResult Function( int value)?  updated,required TResult orElse(),}) {final _that = this;
switch (_that) {
case ProfileCardInitial() when initial != null:
return initial();case ProfileCardUpdated() when updated != null:
return updated(_that.value);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>({required TResult Function()  initial,required TResult Function( int value)  updated,}) {final _that = this;
switch (_that) {
case ProfileCardInitial():
return initial();case ProfileCardUpdated():
return updated(_that.value);}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>({TResult? Function()?  initial,TResult? Function( int value)?  updated,}) {final _that = this;
switch (_that) {
case ProfileCardInitial() when initial != null:
return initial();case ProfileCardUpdated() when updated != null:
return updated(_that.value);case _:
  return null;

}
}

}

/// @nodoc


class ProfileCardInitial implements ProfileCardState {
  const ProfileCardInitial();
  






@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ProfileCardInitial);
}


@override
int get hashCode => runtimeType.hashCode;

@override
String toString() {
    return 'ProfileCardState.initial()';
}


}




/// @nodoc


class ProfileCardUpdated implements ProfileCardState {
  const ProfileCardUpdated(this.value);
  

 final  int value;

/// Create a copy of ProfileCardState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ProfileCardUpdatedCopyWith<ProfileCardUpdated> get copyWith => _$ProfileCardUpdatedCopyWithImpl<ProfileCardUpdated>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is ProfileCardUpdated&&(identical(other.value, value) || other.value == value));
}


@override
int get hashCode {
    return Object.hash(runtimeType,value);
}

@override
String toString() {
    return 'ProfileCardState.updated(value: $value)';
}


}

/// @nodoc
abstract mixin class $ProfileCardUpdatedCopyWith<$Res> implements $ProfileCardStateCopyWith<$Res> {
  factory $ProfileCardUpdatedCopyWith(ProfileCardUpdated value, $Res Function(ProfileCardUpdated) _then) = _$ProfileCardUpdatedCopyWithImpl;
@useResult
$Res call({
 int value
});




}
/// @nodoc
class _$ProfileCardUpdatedCopyWithImpl<$Res>
    implements $ProfileCardUpdatedCopyWith<$Res> {
  _$ProfileCardUpdatedCopyWithImpl(this._self, this._then);

  final ProfileCardUpdated _self;
  final $Res Function(ProfileCardUpdated) _then;

/// Create a copy of ProfileCardState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') $Res call({Object? value = null,}) {
  return _then(ProfileCardUpdated(
null == value ? _self.value : value // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
