// Runs presentation actions and emits the corresponding immutable states.
import 'package:flutter_bloc/flutter_bloc.dart';

import "profile_card_state.dart";

/// Runs presentation actions and emits the corresponding immutable states.
class ProfileCardCubit extends Cubit<ProfileCardState> {
  ProfileCardCubit() : super(const ProfileCardState.initial());

  void update(int value) {
    if (!isClosed) emit(ProfileCardState.updated(value));
  }
}
