// Defines navigation paths and connects routes to presentation factories.
/// Defines navigation paths and connects routes to presentation factories.
class RouteNames {
  RouteNames._();
  static const root = '/';

  static const dashboard = '/sign-in';

  static const catalog = "/catalog";

  static const details = '/details';
}
