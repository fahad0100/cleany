// Creates presentation widgets and owns their Cubit/Bloc providers.
// Presentation factories are wired here, keeping the router independent of
// controllers and data-layer implementation details.
import 'package:flutter/widgets.dart';
import 'package:get_it/get_it.dart';

import '../../core/localization/generated/app_localizations.dart';

import "package:test_cleany_project/modules/dashboard/presentation/pages/dashboard_page.dart";
import 'package:flutter_bloc/flutter_bloc.dart';
import "package:test_cleany_project/modules/dashboard/presentation/cubit/dashboard_cubit.dart";
import "package:test_cleany_project/features/catalog/presentation/pages/catalog_page.dart";
import "package:test_cleany_project/features/catalog/presentation/bloc/catalog_bloc.dart";
import "package:test_cleany_project/features/catalog/presentation/bloc/catalog_event.dart";
import "package:test_cleany_project/modules/dashboard/subfeatures/details/presentation/pages/details_page.dart";
import "package:test_cleany_project/modules/dashboard/subfeatures/details/presentation/cubit/details_cubit.dart";
import "package:test_cleany_project/shared/widgets/profile_card/widgets/profile_card_widget.dart";
import "package:test_cleany_project/shared/widgets/profile_card/cubit/profile_card_cubit.dart";
import 'package:test_cleany_project/shared/components/status_badge/widgets/status_badge_widget.dart';
import 'package:test_cleany_project/shared/components/status_badge/bloc/status_badge_bloc.dart';
import "package:test_cleany_project/modules/dashboard/subfeatures/empty_state/widgets/empty_state_widget.dart";

/// Creates presentation widgets and owns their Cubit/Bloc providers.
class FeaturePages {
  FeaturePages._();
  static Widget placeholder(GetIt container) => Builder(
    builder: (context) =>
        Center(child: Text(AppLocalizations.of(context).welcome)),
  );

  static Widget dashboard(GetIt container) => BlocProvider<DashboardCubit>(
    create: (_) => container<DashboardCubit>()..load(),
    child: const DashboardPage(),
  );

  static Widget catalog(GetIt container) => BlocProvider<CatalogBloc>(
    create: (_) =>
        container<CatalogBloc>()..add(const CatalogEvent.requested()),
    child: const CatalogPage(),
  );

  static Widget details(GetIt container) => BlocProvider<DetailsCubit>(
    create: (_) => container<DetailsCubit>()..load(),
    child: const DetailsPage(),
  );

  static Widget profileCard(GetIt container) => BlocProvider<ProfileCardCubit>(
    create: (_) => container<ProfileCardCubit>(),
    child: const ProfileCardWidget(),
  );

  static Widget statusBadge(GetIt container) => BlocProvider<StatusBadgeBloc>(
    create: (_) => container<StatusBadgeBloc>(),
    child: const StatusBadgeWidget(),
  );

  static Widget emptyState(GetIt container) => const EmptyStateWidget();
}
