// Registers application-scoped services and factory presentation controllers.
import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';

import '../config/app_config.dart';
import '../../core/network/dio/dio_client.dart';

import "package:test_cleany_project/modules/dashboard/data/datasources/dashboard_remote_data_source.dart";
import "package:test_cleany_project/modules/dashboard/data/repositories/dashboard_repository_impl.dart";
import "package:test_cleany_project/modules/dashboard/domain/repositories/dashboard_repository.dart";
import "package:test_cleany_project/modules/dashboard/domain/usecases/get_dashboard.dart";
import "package:test_cleany_project/core/network/retrofit/dashboard_api.dart";
import "package:test_cleany_project/modules/dashboard/presentation/cubit/dashboard_cubit.dart";
import "package:test_cleany_project/features/catalog/data/datasources/catalog_remote_data_source.dart";
import "package:test_cleany_project/features/catalog/data/repositories/catalog_repository_impl.dart";
import "package:test_cleany_project/features/catalog/domain/repositories/catalog_repository.dart";
import "package:test_cleany_project/features/catalog/domain/usecases/get_catalog.dart";
import 'package:test_cleany_project/core/network/retrofit/catalog_api.dart';
import "package:test_cleany_project/features/catalog/presentation/bloc/catalog_bloc.dart";
import "package:test_cleany_project/modules/dashboard/subfeatures/details/data/datasources/details_remote_data_source.dart";
import "package:test_cleany_project/modules/dashboard/subfeatures/details/data/repositories/details_repository_impl.dart";
import "package:test_cleany_project/modules/dashboard/subfeatures/details/domain/repositories/details_repository.dart";
import "package:test_cleany_project/modules/dashboard/subfeatures/details/domain/usecases/get_details.dart";
import 'package:test_cleany_project/core/network/retrofit/details_api.dart';
import "package:test_cleany_project/modules/dashboard/subfeatures/details/presentation/cubit/details_cubit.dart";
import "package:test_cleany_project/shared/widgets/profile_card/cubit/profile_card_cubit.dart";
import 'package:test_cleany_project/shared/components/status_badge/bloc/status_badge_bloc.dart';

// One composition root. Application services live in an explicit app scope.
// Repositories are lazy singletons; presentation controllers are factories.
/// Registers application-scoped services and factory presentation controllers.
Future<void> configureDependencies(GetIt container, AppConfig config) async {
  container.pushNewScope(scopeName: 'app');
  try {
    container.registerSingleton<AppConfig>(config);
    container.registerLazySingleton<Dio>(
      () => createDio(config.apiBaseUrl),
      dispose: (dio) => dio.close(force: true),
    );
    registerFeatureDependencies(container);
  } catch (_) {
    await container.popScope();
    rethrow;
  }
}

/// Registers application-scoped services and factory presentation controllers.
void registerFeatureDependencies(GetIt container) {
  container.registerLazySingleton<DashboardApi>(() => DashboardApi(container<Dio>()));
  container.registerLazySingleton<DashboardRemoteDataSource>(
    () => DashboardRemoteDataSource(container<DashboardApi>()),
  );
  container.registerLazySingleton<DashboardRepository>(
    () => DashboardRepositoryImpl(container<DashboardRemoteDataSource>()),
  );

  container.registerFactory<DashboardCubit>(
    () => DashboardCubit(GetDashboard(container<DashboardRepository>())),
  );

  container.registerLazySingleton<CatalogApi>(
    () => CatalogApi(container<Dio>()),
  );
  container.registerLazySingleton<CatalogRemoteDataSource>(
    () => CatalogRemoteDataSource(container<CatalogApi>()),
  );
  container.registerLazySingleton<CatalogRepository>(
    () => CatalogRepositoryImpl(container<CatalogRemoteDataSource>()),
  );
  container.registerLazySingleton<GetCatalog>(
    () => GetCatalog(container<CatalogRepository>()),
  );

  container.registerFactory<CatalogBloc>(
    () => CatalogBloc(container<GetCatalog>()),
  );

  container.registerLazySingleton<DetailsApi>(
    () => DetailsApi(container<Dio>()),
  );
  container.registerLazySingleton<DetailsRemoteDataSource>(
    () => DetailsRemoteDataSource(container<DetailsApi>()),
  );
  container.registerLazySingleton<DetailsRepository>(
    () => DetailsRepositoryImpl(container<DetailsRemoteDataSource>()),
  );
  container.registerLazySingleton<GetDetails>(
    () => GetDetails(container<DetailsRepository>()),
  );

  container.registerFactory<DetailsCubit>(
    () => DetailsCubit(container<GetDetails>()),
  );

  container.registerFactory<ProfileCardCubit>(() => ProfileCardCubit());

  container.registerFactory<StatusBadgeBloc>(() => StatusBadgeBloc());

  container.registerLazySingleton<GetDashboard>(
    () => GetDashboard(container<DashboardRepository>()),
  );
}

/// Registers application-scoped services and factory presentation controllers.
Future<void> disposeDependencies(GetIt container) => container.popScope();
