// Declares API endpoints returning raw JSON; Retrofit generates the HTTP implementation.
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
part 'details_api.g.dart';

/// Declares API endpoints returning raw JSON; Retrofit generates the HTTP implementation.
@RestApi()
abstract class DetailsApi {
  factory DetailsApi(Dio dio, {String? baseUrl}) = _DetailsApi;
  @GET("/details")
  Future<Map<String, Object?>> fetch();
}
